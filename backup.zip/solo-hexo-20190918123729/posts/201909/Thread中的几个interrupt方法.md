title: Thread中的几个interrupt方法
date: '2019-09-18 12:26:24'
updated: '2019-09-18 12:32:06'
tags: [Thread, interrupt, 中断]
permalink: /articles/2019/09/18/1568780784540.html
---
### 1. public void interrupt()
非 static 方法，在一个线程中调用自己或另一个线程对象(objThread)的 interrupt()方法，会给线程 objThread 发送一个中断信号，将该线程的中断标志位(_interrupted)置为 1

```Java
public void interrupt() {
    if (this != Thread.currentThread())
        checkAccess();

    synchronized (blockerLock) {
        Interruptible b = blocker;
        if (b != null) {
            interrupt0();           // Just to set the interrupt flag
            b.interrupt(this);
            return;
        }
    }
    interrupt0();
}
```

### 2. public static boolean interrupted()
static 方法，检查当前线程是否被中断，并清除中断状态(_interrupted 置为 0)

```Java
public static boolean interrupted() {
    return currentThread().isInterrupted(true);
}
```

### 3. public boolean isInterrupted()
非 static 方法，用于检查被调用线程是否被中断，不会清除中断状态

```Java
public boolean isInterrupted() {
    return isInterrupted(false);
}
```

---
### native 方法源码跟踪（详细代码可下载 [openjdk 源码](http://www.zousanchuan.com/articles/2019/09/17/1568715638871.html) 查看）：

#### 1. interrupt0 方法执行流程：

```java
private native void interrupt0();
```

```c++
//  jdk/src/share/native/java/lang/Thread.c:54
static JNINativeMethod methods[] = {
    ...................
    {"interrupt0",       "()V",        (void *)&JVM_Interrupt},
    ...................
};
```

```c++
//  hotspot/src/share/vm/prims/jvm.cpp:3289
JVM_ENTRY(void, JVM_Interrupt(JNIEnv* env, jobject jthread))
  JVMWrapper("JVM_Interrupt");

  // Ensure that the C++ Thread and OSThread structures aren't freed before we operate
  oop java_thread = JNIHandles::resolve_non_null(jthread);
  MutexLockerEx ml(thread->threadObj() == java_thread ? NULL : Threads_lock);
  // We need to re-resolve the java_thread, since a GC might have happened during the
  // acquire of the lock
  JavaThread* thr = java_lang_Thread::thread(JNIHandles::resolve_non_null(jthread));
  if (thr != NULL) {
    Thread::interrupt(thr);
  }
JVM_END
```

```c++
//  hotspot/src/share/vm/runtime/thread.cpp:804
void Thread::interrupt(Thread* thread) {
  trace("interrupt", thread);
  debug_only(check_for_dangling_thread_pointer(thread);)
  os::interrupt(thread);
}
```

```c++
//  hotspot/src/os/linux/vm/os_linux.cpp:4192
void os::interrupt(Thread* thread) {
  assert(Thread::current() == thread || Threads_lock->owned_by_self(),
    "possibility of dangling Thread pointer");

  OSThread* osthread = thread->osthread();

  if (!osthread->interrupted()) {
    osthread->set_interrupted(true);
    // More than one thread can get here with the same value of osthread,
    // resulting in multiple notifications.  We do, however, want the store
    // to interrupted() to be visible to other threads before we execute unpark().
    OrderAccess::fence();
    ParkEvent * const slp = thread->_SleepEvent ;
    if (slp != NULL) slp->unpark() ;
  }

  // For JSR166. Unpark even if interrupt status already was set
  if (thread->is_Java_thread())
    ((JavaThread*)thread)->parker()->unpark();

  ParkEvent * ev = thread->_ParkEvent ;
  if (ev != NULL) ev->unpark() ;
}
```

```c++
//  hotspot/src/share/vm/runtime/osThread.hpp:89
void set_interrupted(bool z) { _interrupted = z ? 1 : 0; }
```

---
#### 2. isInterrupted 方法执行流程

```Java
private native boolean isInterrupted(boolean ClearInterrupted);
```

```c++
//  jdk/src/share/native/java/lang/Thread.c:55  
static JNINativeMethod methods[] = {  
 ...................  
 {"isInterrupted",    "(Z)Z",       (void *)&JVM_IsInterrupted},  
 ...................  
};  
```

```c++
//  hotspot/src/share/vm/prims/jvm.cpp:3304  
JVM_QUICK_ENTRY(jboolean, JVM_IsInterrupted(JNIEnv* env, jobject jthread, jboolean clear_interrupted))
  JVMWrapper("JVM_IsInterrupted");

  // Ensure that the C++ Thread and OSThread structures aren't freed before we operate
  oop java_thread = JNIHandles::resolve_non_null(jthread);
  MutexLockerEx ml(thread->threadObj() == java_thread ? NULL : Threads_lock);
  // We need to re-resolve the java_thread, since a GC might have happened during the
  // acquire of the lock
  JavaThread* thr = java_lang_Thread::thread(JNIHandles::resolve_non_null(jthread));
  if (thr == NULL) {
    return JNI_FALSE;
  } else {
    return (jboolean) Thread::is_interrupted(thr, clear_interrupted != 0);
  }
JVM_END
  
```

```c++
//  hotspot/src/share/vm/runtime/thread.cpp:810  
bool Thread::is_interrupted(Thread* thread, bool clear_interrupted) {  
 trace("is_interrupted", thread);  
 debug_only(check_for_dangling_thread_pointer(thread);)  
 // Note:  If clear_interrupted==false, this simply fetches and  
 // returns the value of the field osthread()->interrupted().  
 return os::is_interrupted(thread, clear_interrupted);  
}  
  
```

```c++
//  hotspot/src/os/linux/vm/os_linux.cpp:4217  
bool os::is_interrupted(Thread* thread, bool clear_interrupted) {  
 assert(Thread::current() == thread || Threads_lock->owned_by_self(),  
 "possibility of dangling Thread pointer");  
  
 OSThread* osthread = thread->osthread();  
  
 bool interrupted = osthread->interrupted();  
  
 if (interrupted && clear_interrupted) {  
 osthread->set_interrupted(false);  
 // consider thread->_SleepEvent->reset() ... optional optimization  
 }  
  
 return interrupted;  
}  
  
```

```c++
//  hotspot/src/share/vm/runtime/osThread.hpp:88  
volatile bool interrupted() const    { return _interrupted != 0; }  
```

