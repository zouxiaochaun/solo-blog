title: Linux 常用命令
date: '2019-09-21 20:02:32'
updated: '2019-09-27 15:08:33'
tags: [linux]
permalink: /articles/2019/09/21/1569067352530.html
---
# 日志搜索

1. 统计日志中 transactionId 出现的次数
`qIGt '关键字 1' 20190801 -E| grep '关键字 2' | grep -o 'transactionId":"[[:digit:]]+' | cut -f3 -d""" | sort | uniq -c | sort -rn`
(查询指定`关键字1`的日志 | 筛选出包含`关键字2`的日志 | 输出事务号 | 以&quot;为分隔符分段,刷选出第三段 | 排序 | 去重并统计重复次数 | 识别每行开头的数字并从小到大排序)

# VIM

`dd` 删除游标所在的一整行(常用)
`ndd` 删除光标所在的向下 n 行，例如 20dd 则是删除光标所在的向下 20 行
`d1G` 删除光标所在到第一行的所有数据
`dG` 删除光标所在到最后一行的所有数据
`d$` 删除光标所在处，到该行的最后一个字符
`d0(数字 0)` 删除光标所在到该行的最前面的一个字符
`x,X` x 向后删除一个字符(相当于[del]按键),X 向前删除一个字符(相当于[backspace]即退格键)
`nx` n 为数字，连续向后删除 n 个字符
`u` 撤销刚才的操作
`ctrl+r` 恢复刚才撤销的动作
`:n` 跳转到第 n 行

# grep

`-P` 让 grep 使用 perl 的正则表达式语法
`-o` 只输出匹配到的部分，可与 **-P** 合用
`-v` 逆反模示，只输出**不含**指定字符串的句子

# awk

### awk 内置变量

* `NF`：当前行有多少个字段
* `NR`：当前处理的是第几行
* `FILENAME`：当前文件名
* `FS`：字段分隔符，默认是空格和制表符。
* `RS`：行分隔符，用于分割每一行，默认是换行符。
* `OFS`：输出字段的分隔符，用于打印时分隔字段，默认为空格。
* `ORS`：输出记录的分隔符，用于打印时分隔记录，默认为换行符。
* `OFMT`：数字输出的格式，默认为`％.6g`。

### awk 内置函数

* [Built-in (The GNU Awk User’s Guide)](https://www.gnu.org/software/gawk/manual/html_node/Built_002din.html#Built_002din)

### awk 应用实例

* 查询 `2019*/loan.csv` 文件中以`,`作为分隔符，排除第一行，倒数第二个字段等于 90 的文件名、行数、字段值
`awk -F',' '{if(NR > 1 && $(NF-1)==90) print FILENAME"-"NR"-"$(NF-1)}' 2019*/loan.csv`

### 转载教程

* [awk 入门教程](http://www.ruanyifeng.com/blog/2018/11/awk.html)

