title: jdk native方法 源码查看方法
date: '2019-09-17 18:20:38'
updated: '2019-09-17 18:21:36'
tags: [随手记]
permalink: /articles/2019/09/17/1568715638871.html
---
openjdk 源码地址：[http://jdk.java.net/java-se-ri/8](http://jdk.java.net/java-se-ri/8)
![image.png](https://img.hacpai.com/file/2019/09/image-818a66d0.png)
点击 **zip file** 下载，压缩包中即为 openjdk 源码
java.lang.Thread 中 native 方法的源码路径为

> /jdk/src/share/native/Java/lang/Thread.c

