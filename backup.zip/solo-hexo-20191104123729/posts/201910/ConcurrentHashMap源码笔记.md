title: ConcurrentHashMap 源码笔记
date: '2019-10-29 17:21:15'
updated: '2019-10-29 17:21:15'
tags: [juc]
permalink: /articles/2019/10/29/1572340875630.html
---
### ConcurrentHashMap 总结

1. 采用哈希表 + 链表 + 红黑树的数据结构组织数据，链表转红黑树的条件是链表长度大于等于 8 并且哈希表长度大于等于 64，红黑树转回链表的条件是红黑树内节点个数小于等于 6
2. `sizeCtl`参数在不同的状态下有不同的值代表不同含义：
   1. `sizeCtl>0` 哈希表的扩容阈值，此时`sizeCtl==0.75*哈希表长度`，如果哈希表内`(K-V)总数>=sizeCtl`，哈希表会发起扩容；
   2. `sizeCtl==-1` 哈希表正在初始化；
   3. `sizeCtl<-1` 哈希表正在扩容，此时`sizeCtl`高 16 位是容量戳，哈希表在不同容量下容量戳不同，低 16 位 =(参与哈希表扩容的线程数 +1)
3. 红黑树被封装在`TreeBin`对象中，哈希桶内存放的是`TreeBin`对象。`TreeBin`对象中持有红黑树根节点的引用，红黑树的增删改查操作都通过`TreeBin`代理实现
4. `ForwardingNode`是触发多线程扩容入口，该对象不存放实际数据，只在哈希表扩容过程中用于链接新旧哈希表，当线程在执行`put` / `remove` / `clear` 等方法时如果发现`ForwardingNode`节点，会先参与协助扩容迁移数据，然后在新的哈希表中执行对应操作；`get`方法发现`ForwardingNode`节点后，会直接通过`ForwardingNode`链接前往新的哈希表查找指定的 key
5. `ConcurrentHashMap`的扩容过程可以由多个线程同步完成。新的哈希表的初始化由单线程完成，数据迁移由多线程完成，每个线程负责哈希表内一段连续的哈希桶的数据迁移，以哈希表下标 length-1 到 0 的顺序依次分派任务，每个线程的任务量为 `length/NCPU/8` 个哈希桶 (`NCPU`是 CPU 核心数)，最少 16 个
6. `ConcurrentHashMap`通过自旋 +CAS 锁的方式来保证数据安全，CAS 的基本思想就是比较变量值是否与指定值相同，相同就修改成指定的新值，并返回`true`，不相同直接返回`false`，这是一个无锁化的修改值的操作，他可以大大降低锁代理的性能消耗。
7. `ConcurrentHashMap`的节点总数统计由两部分体现，一部分是`long`型变量`baseCount`，另一部分是一个`CounterCell`数组，当出现并发竞争，更新`baseCount`变量失败时，会将数值更新到`CounterCell`数组中，该数组初始容量 2，并发竞争激烈时会以 2 倍的效率扩容，最大容量`2*(NCPU-1)`
8. 在对哈希桶内数据进行写操作之前会通过`synchronized` 锁住哈希桶，这也是分段锁的思想，但是比 JDK7 中的`segment`锁粒度更细，可承受更高并发
![image.png](https://img.hacpai.com/file/2019/10/image-b4731c72.png)

### get 方法

1. 如果`key`对应哈希桶内为链表，遍历链表查找
2. 如果哈希桶内为红黑树，调用`TreeBin`的 `find` 方法查找
3. 如果哈希桶内为 `ForwardingNode` 节点，说明哈希桶此时正在扩容，调用 `ForwardingNode` 的 `find` 方法，会在扩容后的哈希表中查找 `key`

```java
public V get(Object key) {
    Node<K,V>[] tab; Node<K,V> e, p; int n, eh; K ek;
    int h = spread(key.hashCode());
    // 找到key对应的哈希桶，桶内无值返回null
    if ((tab = table) != null && (n = tab.length) > 0 &&
        (e = tabAt(tab, (n - 1) & h)) != null) {
        // 如果头结点即为所要找的key，返回对应value
        if ((eh = e.hash) == h) {
            if ((ek = e.key) == key || (ek != null && key.equals(ek)))
                return e.val;
        }
        // 如果桶内为ForwardingNode节点或红黑树结构，调用对应的find方法查找key
        // ForwardingNode节点的find方法会去扩容后的哈希表中查找key
        else if (eh < 0)
            return (p = e.find(h, key)) != null ? p.val : null;
        // 桶内为链表结构，则遍历链表查找key
        while ((e = e.next) != null) {
            if (e.hash == h &&
                ((ek = e.key) == key || (ek != null && key.equals(ek))))
                return e.val;
        }
    }
    return null;
}
```

### put 方法

1. `key`和`value`都不允许为`null`
2. 插入之前先检查哈希表是否初始化，没有初始化会首先调用`initTable()`方法初始化哈希表
3. 如果`key`对应的哈希桶内没有其他节点，直接实例化一个`Node`节点存入该哈希桶内
4. 如果`key`对应的哈希桶内存放的是一个`ForwardingNode`节点(`hash`值为**MOVED**)，说明哈希表正在扩容，调用`helpTransfer`方法协助哈希表扩容
5. 插入`K-V`之前会对哈希桶加锁，禁止其他线程修改此哈希桶
6. 如果哈希桶内是链表结构，遍历链表查找 key，如果该`key`已存在，用新的`value`覆盖`oldValue`；如果该`key`不存在，实例化`Node`节点挂在链表尾部
7. 如果哈希桶内是红黑树结构，调用`TreeBin`的`putTreeVal`方法，该方法的作用是如果找到 key，返回对应的`TreeNode`，如果没有找到`key`，将`K-V`插入红黑树
8. 插入完成后会检查对应哈希桶内元素个数是否大于等于树形转换阈值`TREEIFY_THRESHOLD=8`，如果大于该值，则会调用`treeifyBin`方法，在该方法中会检查哈希表的长度是否小于 64，如果小于 64 则不会将数据结构转成红黑树，而是对哈希表扩容
9. 最后，更新 K-V 统计计数(参考`addCount`)

```java
public V put(K key, V value) {
    // false: 如果对应的key已存在value，删除原来的，保存新的
    return putVal(key, value, false);
}

/** Implementation for put and putIfAbsent */
final V putVal(K key, V value, boolean onlyIfAbsent) {
    // key 和 value 都不允许为空
    if (key == null || value == null) throw new NullPointerException();
    int hash = spread(key.hashCode());
    int binCount = 0;
    for (Node<K,V>[] tab = table;;) {
        Node<K,V> f; int n, i, fh;
        // 检查并初始化哈希表
        if (tab == null || (n = tab.length) == 0)
            tab = initTable();
        else if ((f = tabAt(tab, i = (n - 1) & hash)) == null) {
            // 如果哈希表中key对应位置为空，那么直接将K-V存入该位置
            // casTabAt 内部为CAS算法判断并赋值，赋值成功返回true，存入K-V成功
            //          赋值失败返回false，说明有其他线程在 tabAt 之后和 casTabAt中的CAS之前存入了其他K-V
            if (casTabAt(tab, i, null,
                         new Node<K,V>(hash, key, value, null)))
                break;                   // no lock when adding to empty bin
        }
        // 如果哈希表中key对应位置的头结点的hash值为MOVED，说明其他线程正在进行扩容操作，当前线程参与协助扩容
        else if ((fh = f.hash) == MOVED)
            tab = helpTransfer(tab, f);
        else {
            V oldVal = null;
            // 对链表/树 的头结点/根节点对象加锁
            synchronized (f) {
                // 校验头结点是否被更改
                if (tabAt(tab, i) == f) {
                    // fh >= 0说明此哈希桶内为链表结构
                    if (fh >= 0) {
                        binCount = 1;
                        // 遍历查找链表是否已存在给定的key
                        for (Node<K,V> e = f;; ++binCount) {
                            K ek;
                            // 如果已存在key，则根据onlyIfAbsent标志，来决定是否用新值替换原有的值
                            if (e.hash == hash &&
                                ((ek = e.key) == key ||
                                 (ek != null && key.equals(ek)))) {
                                oldVal = e.val;
                                if (!onlyIfAbsent)
                                    e.val = value;
                                break;
                            }
                            Node<K,V> pred = e;
                            // 如果链表中不存在给定的key，则将K-V挂在链表尾部
                            if ((e = e.next) == null) {
                                pred.next = new Node<K,V>(hash, key,
                                                          value, null);
                                break;
                            }
                        }
                    }
                    // 如果哈希表当前位置已由链表结构转换成树结构，则调用TreeBin.putTreeVal(int h, K k, V v)方法来存入K-V
                    // TreeBin.putTreeVal(int h, K k, V v)方法的功能是查找给定的K，找到则返回对应K-V对象，没有找到则插入K-V（详见）
                    else if (f instanceof TreeBin) {
                        Node<K,V> p;
                        binCount = 2;
                        if ((p = ((TreeBin<K,V>)f).putTreeVal(hash, key,
                                                       value)) != null) {
                            oldVal = p.val;
                            if (!onlyIfAbsent)
                                p.val = value;
                        }
                    }
                }
            }
            if (binCount != 0) {
                if (binCount >= TREEIFY_THRESHOLD)
                // 如果哈希桶内K-V总数大于等于树形转换阈值(TREEIFY_THRESHOLD = 8)，那么将当前位置由链表结构转换成红黑树结构
                    // 详见(2#treeifyBin -- 链表结构转换成树形结构)
                    treeifyBin(tab, i);
                if (oldVal != null)
                    return oldVal;
                break;
            }
        }
    }
    // 更新K-V统计计数(见7#addCount)
    addCount(1L, binCount);
    return null;
}
```

### initTable 初始化哈希表

1. 如果构造方法没有指定哈希表容量，那么将哈希表容量初始化为`DEFAULT_CAPACITY=16`
2. 如果在初始化过程中有其他线程正在初始化或者哈希表扩容，当前线程会调用`Thread.yield()`来让出 CPU，等待 CPU 下一次调度当前线程
3. 初始化完成后会将`sizeCtl`设置为哈希表容量的 0.75 倍 `(sc=n-(n>>>2))`

```java
private final Node<K,V>[] initTable() {
    Node<K,V>[] tab; int sc;
    // 无限尝试初始化哈希表直至初始化成功
    while ((tab = table) == null || tab.length == 0) {
        // 如果 sizeCtl<0 说明有其他线程正在初始化或扩容哈希表，此时让出CPU，等待CPU再次调度该线程
        if ((sc = sizeCtl) < 0)
            Thread.yield(); // lost initialization race; just spin
        // CAS算法比较sizeCtl是否还是原值
        // 如果sc不是原值，1: 在sc赋值之后和判断sc<0之前时间段内 或 判断sc<0之后和CAS操作之前时间段内，有其他线程完成了对哈希表的初始化操作。2: 在if ((sc = sizeCtl) < 0)判断完成之后和CAS操作之前时间段内，有其他线程抢先进入哈希表的初始化流程; 
        // 将sizeCtl赋值-1，表示此时有线程正在对哈希表进行扩容操作
        else if (U.compareAndSwapInt(this, SIZECTL, sc, -1)) {
            try {
                // 再次判断哈希表是否为空，在while判断和sc赋值时间段内其他线程可能完成了对哈希表的初始化
                if ((tab = table) == null || tab.length == 0) {
                    // 初始哈希表长度为DEFAULT_CAPACITY=16
                    int n = (sc > 0) ? sc : DEFAULT_CAPACITY;
                    @SuppressWarnings("unchecked")
                    // 初始化哈希表，容量为sizeCtl
                    Node<K,V>[] nt = (Node<K,V>[])new Node<?,?>[n];
                    table = tab = nt;
                    // 将sizeCtl更新为原来的0.75倍
                    sc = n - (n >>> 2);
                }
            } finally {
                sizeCtl = sc;
            }
            break;
        }
    }
    return tab;
}
```

### helpTransfer 准备迁移数据

正式开始扩容之前的准备工作，参数检查，更新 `sizeCtl`

```java
final Node<K,V>[] helpTransfer(Node<K,V>[] tab, Node<K,V> f) {
    Node<K,V>[] nextTab; int sc;
    // 参数检查
    if (tab != null && (f instanceof ForwardingNode) &&
        (nextTab = ((ForwardingNode<K,V>)f).nextTable) != null) {
        // 生成容量戳
        int rs = resizeStamp(tab.length);
        while (nextTab == nextTable && table == tab &&
               (sc = sizeCtl) < 0) {
            // 和(3#tryPresize)方法中一样，在参与哈希表扩容之前要检查哈希表是否已扩容完成，以及参与扩容的线程数是否超出最大限制
            if ((sc >>> RESIZE_STAMP_SHIFT) != rs || sc == rs + 1 ||
                sc == rs + MAX_RESIZERS || transferIndex <= 0)
                break;
            // 开始调用transfer方法协助扩容
            if (U.compareAndSwapInt(this, SIZECTL, sc, sc + 1)) {
                transfer(tab, nextTab);
                break;
            }
        }
        return nextTab;
    }
    return table;
}
```

### treeifyBin 链表转红黑树

1. 在转成树结构之前会先检查哈希表长度是否超过树形化阈值(`MIN_TREEIFY_CAPACITY=64`)，也就是说哈希桶内数据结构由链表转成红黑树需满足两个条件：a、桶内元素个数大于等于 8；b、哈希表长度大于等于 64
2. 执行树形化过程之前会先将链表头结点用`synchronized` 加锁，禁止其他线程进入
3. 树形化分为两个过程：1、将`Node`链表转成`TreeNode`链表；2、实例化`TreeBin`，链表转换成红黑树的过程在`TreeBin`的构造方法中完成
4. 转换后哈希桶内存储的对象是`TreeBin`对象，`TreeBin`对象中同时持有红黑树的根节点和`TreeNode`链表的头结点

```java
private final void treeifyBin(Node<K,V>[] tab, int index) {
    Node<K,V> b; int n, sc;
    if (tab != null) {
        // 如果哈希表容量小于最小树形化阈值(MIN_TREEIFY_CAPACITY = 64)
        // 则调用tryPresize方法调整哈希表容量而不是转换哈希桶内数据结构
        if ((n = tab.length) < MIN_TREEIFY_CAPACITY)
            tryPresize(n << 1);
        else if ((b = tabAt(tab, index)) != null && b.hash >= 0) {
            synchronized (b) {
                if (tabAt(tab, index) == b) {
                    TreeNode<K,V> hd = null, tl = null;
                    // 在for循环中将Node链表转换成TreeNode链表
                    for (Node<K,V> e = b; e != null; e = e.next) {
                        TreeNode<K,V> p =
                            new TreeNode<K,V>(e.hash, e.key, e.val,
                                              null, null);
                        if ((p.prev = tl) == null)
                            hd = p;
                        else
                            tl.next = p;
                        tl = p;
                    }
                    // 在new TreeBin<K,V>(hd)构造方法中才真正将链表结构转换成红黑树结构
                    setTabAt(tab, index, new TreeBin<K,V>(hd));
                }
            }
        }
    }
}
```

### tryPresize 哈希表扩容

1. 如果指定容量大于最大容量`(MAXIMUM_CAPACITY=1<<30=1073741824)`的一半，扩容为最大容量，否则扩容为大于等于指定容量 1.5 倍的最小的 2 的倍数
2. 扩容之前会检查并初始化哈希表
3. 如果扩容容量小于哈希表扩容阈值，不进行扩容
4. 实际上在哈希表扩容过程中`sizeCtl`绑定的是两个参数：1、高`RESIZE_STAMP_BITS=16`位绑定扩容前哈希表长度，不同的容量值会绑定不同的值 (参考 其他方法 resizeStamp)；2、低 `RESIZE_STAMP_SHIFT=32-RESIZE_STAMP_BITS=16`位绑定的是参与哈希表扩容的线程数，值为参与扩容线程数 +1。两个参数组成一个 `int` 型负值，代表哈希表正在进行扩容，eg. ‭`1000 0000 1000 0000 0000 0000 0000 0101‬`代表此时有 4 条线程参与容量为 128 的哈希表的扩容

```java
private final void tryPresize(int size) {
    //如果大小为MAXIMUM_CAPACITY最大总量的一半，那么直接扩容为MAXIMUM_CAPACITY，否则计算最小幂次方
    int c = (size >= (MAXIMUM_CAPACITY >>> 1)) ? MAXIMUM_CAPACITY :
        tableSizeFor(size + (size >>> 1) + 1);
    int sc;
    while ((sc = sizeCtl) >= 0) {
        Node<K,V>[] tab = table; int n;
        // 检查并初始化哈希表
        if (tab == null || (n = tab.length) == 0) {
            n = (sc > c) ? sc : c;
            // cas修改sizeCtl值为-1，表示哈希表正在被初始化
            if (U.compareAndSwapInt(this, SIZECTL, sc, -1)) {
                try {
                    if (table == tab) {
                        @SuppressWarnings("unchecked")
                        Node<K,V>[] nt = (Node<K,V>[])new Node<?,?>[n];
                        table = nt;
                        sc = n - (n >>> 2);
                    }
                } finally {
                    sizeCtl = sc;
                }
            }
        }
        // 指定容量不超过当前容量阈值或者大于最大容量
        else if (c <= sc || n >= MAXIMUM_CAPACITY)
            break;
        else if (tab == table) {
            // rs(sc) 的结构是: 高16位是表的容量戳，表在不同容量下有不同的容量戳
            //             低16位代表参与哈希表扩容的线程数
            // rs = ((1<<15) | int值n的二进制补码形式中最高位的1之前0的个数)
            int rs = resizeStamp(n);
            // sc < 0 代表其他线程正在初始化或扩容哈希表
            if (sc < 0) {
                Node<K,V>[] nt;
                // (sc >>> RESIZE_STAMP_SHIFT) != rs ##表的容量戳不同，即当前线程扩容的目标容量(rs)与当前处于扩容状态的哈希表的目标容量(sc)不一致
                // sc == rs + 1 ## ??
                // sc == rs + MAX_RESIZERS  ## ??
                // (nt = nextTable) == null  ##nextTable正在进行初始化，不需要其他线程协助迁移
                // transferIndex <= 0  ##迁移任务已全部被领取
                if ((sc >>> RESIZE_STAMP_SHIFT) != rs || sc == rs + 1 ||
                    sc == rs + MAX_RESIZERS || (nt = nextTable) == null ||
                    transferIndex <= 0)
                    break;

                if (U.compareAndSwapInt(this, SIZECTL, sc, sc + 1))
                    transfer(tab, nt);
            }
            // 1一共左移(RESIZE_STAMP_SHIFT+RESIZE_STAMP_BITS-1=31)位，此时rs中最高位为1，一定为负值
            // 为什么+2 ? 理解:1(为什么是2):n代表有n-1个线程参与哈希表扩容，当前线程是扩容发起者，因此n=2代表有1个线程参与扩容
            //                2(为什么是+):rs分高16位和低16位，只有低16位才代表线程数，这个数是无符号的
            else if (U.compareAndSwapInt(this, SIZECTL, sc,
                                         (rs << RESIZE_STAMP_SHIFT) + 2))
                // 作为扩容发起者，nextTab为null
                transfer(tab, null);
        }
    }
}
```

### addCount 更新计数

1. 更新`map`中`K-V`计数的方法，`K-V`计数分两部分，`baseCount`和`CounterCell`数组，更新计数是首先会尝试更新`baseCount`，`baseCount`更新失败才将计数更新到`CounterCell`数组中
2. 当需要统计`map`中`K-V`总数时，会将`baseCount`和`CounterCell`数组中的值累加

```java
// x 更新的数值
// check 是否需要检查哈希表是否有必要扩容，负数代表不检查
private final void addCount(long x, int check) {
    CounterCell[] as; long b, s;
    // 尝试直接更新到baseCount
    if ((as = counterCells) != null ||
        !U.compareAndSwapLong(this, BASECOUNT, b = baseCount, s = b + x)) {
        CounterCell a; long v; int m;
        boolean uncontended = true;
        // 如果更新K-v计数器失败，则将数值更新到任意一个CounterCell中
        if (as == null || (m = as.length - 1) < 0 ||
            (a = as[ThreadLocalRandom.getProbe() & m]) == null ||
            !(uncontended =
              U.compareAndSwapLong(a, CELLVALUE, v = a.value, v + x))) {
        	// 如果counterCells为null或者拿到的CounterCell为null或者将数值更新到CounterCell中失败，则调用fullAddCount方法更新数值
            fullAddCount(x, uncontended);
            return;
        }
        if (check <= 1)
            return;
        s = sumCount();
    }
    // check 是否需要检查哈希表是否有必要扩容，负数代表不检查，否则检查扩容
    if (check >= 0) {
        Node<K,V>[] tab, nt; int n, sc;
        // 当扩容之后还需再次检查此时哈希表内K-v总数是否会触发扩容，如果触发了扩容还会再次对哈希表扩容
        // s >= (long)(sc = sizeCtl) 表明sizeCtl即为哈希表的扩容阈值
        while (s >= (long)(sc = sizeCtl) && (tab = table) != null &&
               (n = tab.length) < MAXIMUM_CAPACITY) {
    		// 发起或参与哈希表扩容，详细注释参考tryPresize相关代码
            int rs = resizeStamp(n);
            if (sc < 0) {
                if ((sc >>> RESIZE_STAMP_SHIFT) != rs || sc == rs + 1 ||
                    sc == rs + MAX_RESIZERS || (nt = nextTable) == null ||
                    transferIndex <= 0)
                    break;
                if (U.compareAndSwapInt(this, SIZECTL, sc, sc + 1))
                    transfer(tab, nt);
            }
            else if (U.compareAndSwapInt(this, SIZECTL, sc,
                                         (rs << RESIZE_STAMP_SHIFT) + 2))
                transfer(tab, null);
            s = sumCount();
        }
    }
}
```

### fullAddCount

1. 当`addCount`方法更新`baseCount`失败，就会调用此方法将数值更新到`CounterCell`数组中，调用`size`方法统计`map`中元素个数时会累计`baseCount`和所有`CounterCell`数组中的数值
2. `CounterCell`数组初始容量为 2，每次扩容都以 2 倍的效率扩容，最大容量可取`(NCPU-1)*2`
3. 在对`CounterCell`数组初始化、扩容或更新`CounterCell` 值时都需要加上`cellsBusy` 锁 (`cellsBusy`置 1)，禁止其他线程对`CounterCell`数组进行写操作

```java
private final void fullAddCount(long x, boolean wasUncontended) {
    int h;
    //获取当前线程的probe值作为hash值,如果0则强制初始化当前线程的Probe值，初始化的probe值不为0
    if ((h = ThreadLocalRandom.getProbe()) == 0) {
        ThreadLocalRandom.localInit();      // force initialization
        h = ThreadLocalRandom.getProbe();
        wasUncontended = true;
    }
    boolean collide = false;                // True if last slot nonempty
    for (;;) {
        CounterCell[] as; CounterCell a; int n; long v;
        // counterCells已被初始化
        if ((as = counterCells) != null && (n = as.length) > 0) {
            // 根据线程的probe值获取一个CounterCell，如果对应的CounterCell还没有被初始化，那首先将其初始化
            if ((a = as[(n - 1) & h]) == null) {
                // cellsBusy==1标志此时有线程正在初始化counterCells或counterCells正在扩容，不允许其他线程操作，cellsBusy==0标志counterCells空闲
                if (cellsBusy == 0) {            // Try to attach new Cell
                    // 实例化CounterCell并存储数值
                    CounterCell r = new CounterCell(x); // Optimistic create
                    if (cellsBusy == 0 &&
                        U.compareAndSwapInt(this, CELLSBUSY, 0, 1)) {
                        boolean created = false;
                        try {               // Recheck under lock
                            CounterCell[] rs; int m, j;
                            if ((rs = counterCells) != null &&
                                (m = rs.length) > 0 &&
                                rs[j = (m - 1) & h] == null) {
                                rs[j] = r;
                                created = true;
                            }
                        } finally {
                            cellsBusy = 0;
                        }
                        // 已将数值存入CounterCell，可以直接退出
                        if (created)
                            break;
                        continue;           // Slot is now non-empty
                    }
                }
                collide = false;
            }
            // ??? TODO
            else if (!wasUncontended)       // CAS already known to fail
                wasUncontended = true;      // Continue after rehash
            // 拿到不为null的CounterCell，尝试更新，更新成功退出，更新失败继续尝试其他方案
            else if (U.compareAndSwapLong(a, CELLVALUE, v = a.value, v + x))
                break;
            // counterCells已被扩容 或者 counterCells大小超出限制(counterCells最大为CPU核心数)
            else if (counterCells != as || n >= NCPU)
                collide = false;            // At max size or stale
            else if (!collide)
                collide = true;
            // 检查counterCells是否被其他线程占用
            else if (cellsBusy == 0 &&
                     U.compareAndSwapInt(this, CELLSBUSY, 0, 1)) {
                // 到此说明counterCells已被初始化且容量小于最大容量NCPU且线程对counterCells又并发竞争，此时应对counterCells扩容，，扩容为原容量的2倍
                try {
                    if (counterCells == as) {// Expand table unless stale
                        CounterCell[] rs = new CounterCell[n << 1];
                        for (int i = 0; i < n; ++i)
                            rs[i] = as[i];
                        counterCells = rs;
                    }
                } finally {
                    cellsBusy = 0;
                }
                collide = false;
                continue;                   // Retry with expanded table
            }
            // 拿到一个新的hash值
            h = ThreadLocalRandom.advanceProbe(h);
        }
        else if (cellsBusy == 0 && counterCells == as &&
                 U.compareAndSwapInt(this, CELLSBUSY, 0, 1)) {
            // 初始化counterCells，初始容量为2，只实例化本次操作用到的CounterCell
            boolean init = false;
            try {                           // Initialize table
                if (counterCells == as) {
                    CounterCell[] rs = new CounterCell[2];
                    rs[h & 1] = new CounterCell(x);
                    counterCells = rs;
                    init = true;
                }
            } finally {
                cellsBusy = 0;
            }
            if (init)
                break;
        }
        // 由于counterCells的并发竞争初始化counterCells失败，尝试再次更新baseCount，更新成功直接退出
        else if (U.compareAndSwapLong(this, BASECOUNT, v = baseCount, v + x))
            break;                          // Fall back on using base
    }
}
```

### transfer 哈希表数据迁移

1. 可以有多个线程参与数据迁移，每条线程负责迁移的哈希桶的个数`stride`由哈希表长度和虚拟机可用的 CPU 核心数决定，1 核心允许 8 个线程并发完成扩容，每条线程最少负责`MIN_TRANSFER_STRIDE=16`个哈希桶的数据迁移
2. 发起数据迁移的线程首先需要初始化`nextTab`为哈希表的两倍容量
3. 数据迁移之前会对哈希桶中的对象(链表的头结点 / `TreeBin`/ `ForwardingNode` ) 加锁 (`synchronized`)，禁止其他线程进入
4. 扩容会扩大为原先哈希表长度(length)的两倍(newLength=(length&lt;&lt;1))，在原先哈希表中，节点在哈希表中下标的计算是((lenth-1)&amp;hash)，哈希值相同的都会在同一个链表/红黑树中，扩容两倍后(newLength-1)相对(lenth-1)二进制表示法会在高位增加一位 1，重新计算下标只需要考虑新增加的高位的 1 的影响，即 hash 二进制表示中对应位如果是 0 那么下标不变，如果对应位是 1 那么下标应加上 length
5. 哈希桶内数据完成迁移后会在该哈希桶位置插入一个`ForwardingNode`，标记当前位置全部节点迁移完成
6. 如果哈希桶内结构是红黑树结构，迁移后分开的两组节点数量如果小于等于树转链表阈值`UNTREEIFY_THRESHOLD=6`，则将其转换成 Node 链表存至新的哈希表中，否则还是以红黑树结构存储
7. 最后一条完成数据迁移的线程还需要负责从尾至头检查一遍旧的哈希表中的数据是否全部完成迁移，如果有数据遗漏要将其迁移至新的哈希表 (实际上在当前的设计中并不会出现数据遗漏的问题)
8. 哈希表中全部节点迁移完成后`nextTab`会重新赋值为`null`，`sizeCtl`赋值为扩容后容量的 0.75 倍，此时一定有`transferIndex<= 0`

```java
private final void transfer(Node<K,V>[] tab, Node<K,V>[] nextTab) {
    int n = tab.length, stride;
    // stride每个线程负责迁移的哈希桶的数量，最小值为MIN_TRANSFER_STRIDE = 16
    // 每个线程负责迁移的哈希桶的范围是[transferIndex-stride,transferIndex)，记为[A,B)
    if ((stride = (NCPU > 1) ? (n >>> 3) / NCPU : n) < MIN_TRANSFER_STRIDE)
        stride = MIN_TRANSFER_STRIDE; // subdivide range
    // 如果nextTab == null，代表当前线程是扩容发起者，首先应初始化nextTab，扩容容量为哈希表原始容量的2倍
    if (nextTab == null) {            // initiating
        try {
            @SuppressWarnings("unchecked")
            Node<K,V>[] nt = (Node<K,V>[])new Node<?,?>[n << 1];
            nextTab = nt;
        } catch (Throwable ex) {      // try to cope with OOME
            sizeCtl = Integer.MAX_VALUE;
            return;
        }
        nextTable = nextTab;
        // 从 tab.length-1 开始往 0 进行迁移
        transferIndex = n;
    }
    int nextn = nextTab.length;
    // 标记节点，标记哈希表当前位置所有节点均完成迁移
    ForwardingNode<K,V> fwd = new ForwardingNode<K,V>(nextTab);
    // advance标记当前线程负责的数据迁移任务是否完成
    boolean advance = true;
    // finishing标记当前线程是否正在进行数据迁移后的检查工作
    // 哈希表数据迁移完成后，最后一个退出数据迁移的线程还要负责检查旧的哈希表是否全部数据均已迁移，如果当前线程正处于此阶段，finishing = true
    boolean finishing = false; // to ensure sweep before committing nextTab
    // i: 正在迁移的哈希桶，在while循环中会修正初始值为 transferIndex-1
    // bound: 当前线程负责迁移的哈希桶的下限(包含)
    for (int i = 0, bound = 0;;) {
        Node<K,V> f; int fh;
        // while循环作用是: 
        // 1、检查当前哈希桶是否超出线程所负责迁移的哈希桶区间，以及检查是否超出
        // 2、计算出下一个 transferIndex，transferIndex-=stride，最小取0
        // 3、如果在nextIndex赋值和CAS校验赋值transferIndex的时间段之间有其他线程修改transferIndex的值，可以再次修正i 和 bound
        while (advance) {
            int nextIndex, nextBound;
            // finishing==true 当前线程正在做最后一轮的检查工作
            if (--i >= bound || finishing)
                advance = false;
            else if ((nextIndex = transferIndex) <= 0) {
                i = -1;
                advance = false;
            }
            else if (U.compareAndSwapInt
                     (this, TRANSFERINDEX, nextIndex,
                      nextBound = (nextIndex > stride ?
                                   nextIndex - stride : 0))) {
                bound = nextBound;
                i = nextIndex - 1;
                advance = false;
            }
        }
        if (i < 0 || i >= n || i + n >= nextn) {
            int sc;
            // 如果全部元素均完成迁移，还原nextTable为null，哈希表table指向扩容后的数组，sizeCtl赋值为扩容后容量的0.75倍
            if (finishing) {
                nextTable = null;
                table = nextTab;
                sizeCtl = (n << 1) - (n >>> 1);
                return;
            }
            // 当前线程即将退出数据迁移，sizeCtl-=1
            if (U.compareAndSwapInt(this, SIZECTL, sc = sizeCtl, sc - 1)) {
                // 如果不是最后一个退出数据迁移的线程，直接return，不修改finishing标记
                if ((sc - 2) != resizeStamp(n) << RESIZE_STAMP_SHIFT)
                    return;
                finishing = advance = true;
                // 如果当前线程是最后一个退出数据迁移的线程，那么当前线程还要负责从尾到头检查旧的哈希表是否全部数据均已迁移
                i = n; // recheck before commit
            }
        }
        // 如果哈希表 i 位置为null，那么在该位置插入一个 ForwardingNode
        else if ((f = tabAt(tab, i)) == null)
            advance = casTabAt(tab, i, null, fwd);
        else if ((fh = f.hash) == MOVED)
            advance = true; // already processed
        else {
            // 走到这里说明该位置有节点待迁移，对头结点/根节点加锁，开始迁移节点，禁止其他线程进入
            synchronized (f) {
                if (tabAt(tab, i) == f) {
                    // lowNode,highNode
                    Node<K,V> ln, hn;
                    // 哈希值>=0 说明该哈希桶内为链表结构
                    if (fh >= 0) {
                        int runBit = fh & n;
                        Node<K,V> lastRun = f;
                        // 找到最后一个 该节点及之后的节点迁移后在新的哈希表中位置相同的节点
                        // 扩容的过程中，把一个链表拆分为两个链表，其实是哈希值计算的问题和扩容策略决定的，扩容会扩大原先数组的两倍，在原先数组中，下标的计算是(lenth-1) & hash))，哈希值相同的都会在同一个链表中，而且lenth都是2的倍数，如长度是8的则是，（lenth-1）二进制0111，如果扩大一倍，得16，(lenth-1)也就是01111，一个数如果与0111和与01111，得到值前三位都是一样的，只有第四位不一样。如果是有两个哈希值，如01001（9）和00001（1），未扩容前，9&7=1，1&7=1都是同一个下标的，同一个链表下的。而扩容后，9&15=9，1&15=1，得到的9和1只有第四位不一样，也就是原先在1位置的元素重新hash之后，只能得到1或则9(1+8(length))的位置，，所以原先数组1位置的元素，所有第四位为0的全部放在1下标位置，原先所有第四位为1的都会放到9的下标位置，是对称的。
                        for (Node<K,V> p = f.next; p != null; p = p.next) {
                            int b = p.hash & n;
                            if (b != runBit) {
                                runBit = b;
                                lastRun = p;
                            }
                        }
                        if (runBit == 0) {
                            ln = lastRun;
                            hn = null;
                        }
                        else {
                            hn = lastRun;
                            ln = null;
                        }
                        // 将链表分成两个小链表
                        for (Node<K,V> p = f; p != lastRun; p = p.next) {
                            int ph = p.hash; K pk = p.key; V pv = p.val;
                            if ((ph & n) == 0)
                                ln = new Node<K,V>(ph, pk, pv, ln);
                            else
                                hn = new Node<K,V>(ph, pk, pv, hn);
                        }
                        //CAS存储在nextTable的i位置上
                        setTabAt(nextTab, i, ln);
                        //CAS存储在nextTable的i+n位置上
                        setTabAt(nextTab, i + n, hn);
                        //CAS在原table的i处设置forwordingNode节点，表示这个这个节点已经处理完毕
                        setTabAt(tab, i, fwd);
                        advance = true;
                    }
                    // 该哈希桶内为红黑树结构
                    else if (f instanceof TreeBin) {
                        TreeBin<K,V> t = (TreeBin<K,V>)f;
                        TreeNode<K,V> lo = null, loTail = null;
                        TreeNode<K,V> hi = null, hiTail = null;
                        int lc = 0, hc = 0;
                        // 将红黑树分成两条TreeNode链表
                        for (Node<K,V> e = t.first; e != null; e = e.next) {
                            int h = e.hash;
                            TreeNode<K,V> p = new TreeNode<K,V>
                                (h, e.key, e.val, null, null);
                            if ((h & n) == 0) {
                                if ((p.prev = loTail) == null)
                                    lo = p;
                                else
                                    loTail.next = p;
                                loTail = p;
                                ++lc;
                            }
                            else {
                                if ((p.prev = hiTail) == null)
                                    hi = p;
                                else
                                    hiTail.next = p;
                                hiTail = p;
                                ++hc;
                            }
                        }
                        // 如果两条新的TreeNode链表的长度小于等于树转链表阈值UNTREEIFY_THRESHOLD=6，则将其转换成Node链表，否则转换成红黑树
                        ln = (lc <= UNTREEIFY_THRESHOLD) ? untreeify(lo) :
                            (hc != 0) ? new TreeBin<K,V>(lo) : t;
                        hn = (hc <= UNTREEIFY_THRESHOLD) ? untreeify(hi) :
                            (lc != 0) ? new TreeBin<K,V>(hi) : t;
                        //CAS存储在nextTable的i位置上
                        setTabAt(nextTab, i, ln);
                        //CAS存储在nextTable的i+1位置上
                        setTabAt(nextTab, i + n, hn);
                        //CAS在原table的i处设置forwordingNode节点，表示这个这个节点已经处理完毕
                        setTabAt(tab, i, fwd);
                        advance = true;
                    }
                }
            }
        }
    }
}
```

### size &amp; sumCount &amp; mappingCount  统计 Map 内 K-V 总数

1. `ConcurrentHashMap`中`K-V`总数保存在`baseCount`变量中，如果发生并发竞争写操作时对该值更新失败，则将数值保存到`CounterCell`数组，在统计总数时需要计算两者总和
2. `size()` 和 `mappingCount() `方法都是统计`map`中元素总数，但是`size`方法返回值类型为`int`，可能会溢出；`mappingCount`方法返回值为 long

```java
public int size() {
    long n = sumCount();
    // 最小取0，最大取Integer.MAX_VALUE
    return ((n < 0L) ? 0 :
            (n > (long)Integer.MAX_VALUE) ? Integer.MAX_VALUE :
            (int)n);
}
final long sumCount() {
    CounterCell[] as = counterCells; CounterCell a;
    long sum = baseCount;
    // 除了baseCount中的值还要类加上所有计数盒子中的数值
    if (as != null) {
        for (int i = 0; i < as.length; ++i) {
            if ((a = as[i]) != null)
                sum += a.value;
        }
    }
    return sum;
}
public long mappingCount() {
    long n = sumCount();
    return (n < 0L) ? 0L : n; // ignore transient negative values
}
```

### remove 移除元素

如果此时哈希表正在扩容，先协助扩容。扩容完成后再删除对应元素

```java
    public V remove(Object key) {
        return replaceNode(key, null, null);
    }
    final V replaceNode(Object key, V value, Object cv) {
        int hash = spread(key.hashCode());
        for (Node<K,V>[] tab = table;;) {
            Node<K,V> f; int n, i, fh;
            if (tab == null || (n = tab.length) == 0 ||
                (f = tabAt(tab, i = (n - 1) & hash)) == null)
                break;
            // 哈希表正在扩容，当前线程先协助扩容
            else if ((fh = f.hash) == MOVED)
                tab = helpTransfer(tab, f);
            else {
                V oldVal = null;
                boolean validated = false;
                // 对哈希桶加锁
                synchronized (f) {
                    if (tabAt(tab, i) == f) {
                        if (fh >= 0) {
                            validated = true;
                            for (Node<K,V> e = f, pred = null;;) {
                                K ek;
                                // 找到key
                                if (e.hash == hash &&
                                    ((ek = e.key) == key ||
                                     (ek != null && key.equals(ek)))) {
                                    V ev = e.val;
                                    // 如果没有指定旧值那直接用新值替换
                                    // 如果指定了旧值，那只有在map中的值与指定值相同才会替换成新值
                                    if (cv == null || cv == ev ||
                                        (ev != null && cv.equals(ev))) {
                                        oldVal = ev;
                                        if (value != null)
                                            e.val = value;
                                        // 如果指定的新值为null，直接删除该节点
                                        else if (pred != null)
                                            pred.next = e.next;
                                        else
                                            setTabAt(tab, i, e.next);
                                    }
                                    break;
                                }
                                pred = e;
                                if ((e = e.next) == null)
                                    break;
                            }
                        }
                        else if (f instanceof TreeBin) {
                            validated = true;
                            TreeBin<K,V> t = (TreeBin<K,V>)f;
                            TreeNode<K,V> r, p;
                            // 查找TreeNode
                            if ((r = t.root) != null &&
                                (p = r.findTreeNode(hash, key, null)) != null) {
                                V pv = p.val;
                                if (cv == null || cv == pv ||
                                    (pv != null && cv.equals(pv))) {
                                    oldVal = pv;
                                    if (value != null)
                                        p.val = value;
                                    // 从红黑树中删除节点 p
                                    else if (t.removeTreeNode(p))
                                        setTabAt(tab, i, untreeify(t.first));
                                }
                            }
                        }
                    }
                }
                if (validated) {
                    if (oldVal != null) {
                        if (value == null)
                            // 节点被删除，更新计数
                            addCount(-1L, -1);
                        return oldVal;
                    }
                    break;
                }
            }
        }
        return null;
    }
```

### clear 清空 Map

1. 如果当前哈希桶正在扩容，那么当前线程将先协助扩容迁移数据，然后再遍历删除节点
2. 无论哈希桶内是链表结构还是红黑树结构，删除时都以链表结构遍历删除节点，`TreeNode`节点同时保持了链表结构和树结构特性

```java
public void clear() {
    // 标记被删除的节点的总数，负数表示
    long delta = 0L; // negative number of deletions
    // 从0开始至table.length-1遍历删除哈希表内节点
    int i = 0;
    Node<K,V>[] tab = table;
    while (tab != null && i < tab.length) {
        int fh;
        Node<K,V> f = tabAt(tab, i);
        if (f == null)
            ++i;
        // 当前哈希桶内为ForwardingNode节点，先协助扩容迁移数据，然后对新的哈希表从头遍历删除
        else if ((fh = f.hash) == MOVED) {
            tab = helpTransfer(tab, f);
            i = 0; // restart
        }
        else {
            synchronized (f) {
                if (tabAt(tab, i) == f) {
                    // 如果哈希桶内为红黑树结构，那么取出树的根结点
                    Node<K,V> p = (fh >= 0 ? f :
                                   (f instanceof TreeBin) ?
                                   ((TreeBin<K,V>)f).first : null);
                    // 无论哈希桶内为红黑树还是链表，删除时均以链表方式删除节点
                    while (p != null) {
                        --delta;
                        p = p.next;
                    }
                    // 删除哈希桶内引用
                    setTabAt(tab, i++, null);
                }
            }
        }
    }
    if (delta != 0L)
        // 更新计数，不需要检查扩容
        addCount(delta, -1);
}
```

### 其他方法

```java
// 取大于等于指定值的最小的2的倍数值
private static final int tableSizeFor(int c) {
    int n = c - 1;
    n |= n >>> 1;
    n |= n >>> 2;
    n |= n >>> 4;
    n |= n >>> 8;
    n |= n >>> 16;
    return (n < 0) ? 1 : (n >= MAXIMUM_CAPACITY) ? MAXIMUM_CAPACITY : n + 1;
}

// 生成与哈希表容量绑定的容量戳
static final int resizeStamp(int n) {
    return Integer.numberOfLeadingZeros(n) | (1 << (RESIZE_STAMP_BITS - 1));
}
```

### 红黑树节点(TreeBin)中的锁操作

1. 锁的主要作用是在红黑树重组的过程中阻止读线程进入`TreeBin`的树结构，如果此时读线程进入树结构会出现拿不到正确数据的情况；但此时仍然可以进入链表结构，链表结构的 next 方向重组为原子操作`pred.next = next;`，不会出现并发问题
2. 只处理读写竞争，不处理写写竞争，线程进入`TreeBin`进行写操作`put / remove / replace / clear`之前会直接`synchronized`锁住哈希桶`TreeBin`，其他线程不可能再进入`TreeBin`进行写操作，因此不存在写写竞争的情况
3. 如果其他线程已持有读锁，申请写锁的线程会进入等待状态并阻塞 `LockSupport.park(this);`，直到最后一个释放读锁的线程调用 `LockSupport.unpark(w);`释放等待线程；获取写锁成功后会清除等待状态
4. 多个线程可以同时持有读锁，其实现方式是在`lockState`上累加`READER` 码值，释放读锁时再累减，如果存在等待线程，最后一个释放读锁的线程还要负责释放等待线程
5. 写锁被占用后，其他线程将无法再获取读锁，如果线程获取读锁失败，将直接以链表形式读取数据

```java
volatile Thread waiter;
volatile int lockState;
// values for lockState
static final int WRITER = 1; // set while holding write lock
static final int WAITER = 2; // set when waiting for write lock
static final int READER = 4; // increment value for setting read lock

/**
 * Possibly blocks awaiting root lock.
 */
private final void contendedLock() {
    boolean waiting = false;
    for (int s;;) {
        // 如果没有其他线程拿到读锁
        if (((s = lockState) & ~WAITER) == 0) {
            // 尝试加写锁，并清除等待锁
            if (U.compareAndSwapInt(this, LOCKSTATE, s, WRITER)) {
                if (waiting)
                    // 获取到写锁后，如果自己曾经注册过 WAITER 状态，将其清除
                    waiter = null;
                return;
            }
        }
        // 如果有其他线程获取了读锁，并且当前线程不在等待状态
        else if ((s & WAITER) == 0) {
            // 加上等待锁，注册WAITER状态
            if (U.compareAndSwapInt(this, LOCKSTATE, s, s | WAITER)) {
                waiting = true;
                waiter = Thread.currentThread();
            }
        }
        // 如果当前线程处于等待状态，阻塞自己
        else if (waiting)
            LockSupport.park(this);
    }
}

/**
 * Acquires write lock for tree restructuring.
 */
private final void lockRoot() {
    // 直接加读锁失败，阻塞自己直到成功获取写锁
    if (!U.compareAndSwapInt(this, LOCKSTATE, 0, WRITER))
        contendedLock(); // offload to separate method
}

/**
 * Releases write lock for tree restructuring.
 */
private final void unlockRoot() {
    // 释放写锁，
    lockState = 0;
}
```

### 红黑树基本性质

红黑树基本性质：

1. 节点是红色或黑色。
2. 根节点是黑色。
3. 每个红色节点的两个子节点都是黑色。(从每个叶子到根的所有路径上不能有两个连续的红色节点)
4. 从任一节点到其每个叶子的所有路径都包含相同数目的黑色节点。

旋转或涂色处理可分 5 种情况进行处理：

1. 空树中插入根节点。
2. 插入节点的父节点是黑色。
3. 当前节点的父节点是红色，且叔叔节点（祖父节点的另一个子节点）也是红色。
4. 当前节点的父节点是红色，叔叔节点是黑色，当前节点是右子节点。
5. 当前节点的父节点是红色，叔叔节点是黑色，当前节点是左子节点。

在红黑树中插入节点时，节点的初始颜色都是红色。因为这样可以在插入过程中尽量避免对树的结构进行调整（参考第 4 点性质）。

**情况 1：空树中插入根节点**

违反：性质 2

恢复策略：初始插入的节点均为红色，因此简单将红色重涂为黑色即可。

**情况 2：插入节点的父节点是黑色**

违反：插入的红色节点，未违反任何性质。

恢复策略：什么也不做，无需调整。

**情况 3：当前节点的父节点是红色，且叔叔节点也是红色**

违反：性质 4

此时祖父节点一定存在，否则插入前就已不是红黑树。

与此同时，又分为父节点是祖父节点的左子还是右子，由于对称性，我们只要解开一个方向就可以了。在此，我们只考虑父节点为祖父左子的情况。

同时，还可以分为当前结点是其父结点的左子还是右子，但是处理方式是一样的。我们将此归为同一类。

恢复策略：将当前节点的父节点和叔叔节点涂黑，祖父结点涂红，把当前结点指向祖父节点，以祖父节点为中心重新开始新一轮的旋转或涂色。

**情况 4：当前节点的父节点是红色，叔叔节点是黑色，当前节点是右子节点**

违反：性质 4

恢复策略：以当前节点的父节点作为新的当前节点，以新的当前节点为支撑，进行左旋操作。旋转操作后再按新的情况进行旋转或涂色。

**情况 5：当前节点的父节点是红色，叔叔节点是黑色，当前节点是左子节点**

违反：性质 4

恢复策略：父节点改变为黑色，祖父节点改变为红色，然后再以祖父节点为新的当前节点，做右旋操作。

### 红黑树左旋右旋图解

![image.png](https://img.hacpai.com/file/2019/10/image-6c71736b.png)

![image.png](https://img.hacpai.com/file/2019/10/image-2e48d6be.png)

