title: 基于ReentrantLock和 Condition 的生产者消费者模型
date: '2019-10-30 11:16:15'
updated: '2019-10-30 11:17:53'
tags: [ReentrantLock, 生产者消费者]
permalink: /articles/2019/10/30/1572405375653.html
---
```java
package com.xxx;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Factory<T> {

    public static void main(String[] args) throws InterruptedException {
        Factory<Integer> factory = new Factory<>();
        new Thread(new Producer(factory), "生产者1").start();
        new Thread(new Producer(factory), "生产者2").start();
        new Thread(new Producer(factory), "生产者3").start();
        new Thread(new Consumer(factory), "消费者1").start();
        new Thread(new Consumer(factory), "消费者2").start();
    }

    private T[] items;
    private int index;

    private Lock lock;
    private Condition notFull;
    private Condition notEmpty;

    public Factory(int capacity) {
        items = (T[]) new Object[capacity];
        lock = new ReentrantLock(true);
        notFull = lock.newCondition();
        notEmpty = lock.newCondition();
    }

    public void put(T item) {
        try {
            lock.lock();
            while (size() == capacity()) {
                System.out.println(Thread.currentThread().getName() + " 生产 " + "--仓库满！");
                notFull.await();
            }
            items[index++] = item;
            System.out.println(Thread.currentThread().getName() + " 生产: " + item + " 当前容量:" + size());
            notEmpty.signalAll();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public T take() {
        try {
            lock.lock();
            while (size() == 0) {
                System.out.println(Thread.currentThread().getName() + " 消费 " + "--仓库空！");
                notEmpty.await();
            }
            T item = items[--index];
            System.out.println(Thread.currentThread().getName() + " 消费 " + item + " 当前容量:" + size());
            notFull.signalAll();
            return item;
        } catch (InterruptedException e) {
            e.printStackTrace();
            return null;
        } finally {
            lock.unlock();
        }
    }

    public Factory() {
        this(10);
    }

    private int capacity() {
        return items.length;
    }

    public int size() {
        return index;
    }


}

class Producer implements Runnable {
    private Factory<Integer> producer;

    Producer(Factory<Integer> producer) {
        this.producer = producer;
    }

    @Override
    public void run() {
        while (true) {

            int product = ThreadLocalRandom.current().nextInt(300);
            producer.put(product);
            try {
                TimeUnit.MILLISECONDS.sleep(ThreadLocalRandom.current().nextInt(1500));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Consumer implements Runnable {
    private Factory<Integer> consumer;

    Consumer(Factory<Integer> consumer) {
        this.consumer = consumer;
    }

    @Override
    public void run() {
        while (true) {
            Integer take = consumer.take();
            try {
                TimeUnit.MILLISECONDS.sleep(ThreadLocalRandom.current().nextInt(1500));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}


```
