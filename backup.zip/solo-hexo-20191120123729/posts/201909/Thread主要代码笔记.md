title: Thread 主要代码笔记
date: '2019-09-18 12:26:24'
updated: '2019-09-22 16:11:46'
tags: [Thread, interrupt, 中断]
permalink: /articles/2019/09/18/1568780784540.html
---
# 实例化一个 Thread

在 Thread 类中一共 8 个构造方法，其具体实现全部由 init() 方法完成，主要步骤：

1. 设置 name、stackSize、tid、group、daemon、priority、contextClassLoader、inheritableThreadLocals 等参数的初始值，除了 name、stackSize、tid 以外其他参数都默认跟当前线程参数值保持一致
2. 线程组中 nUnstartedThreads ++
3. 设置内核线程 优先级参数 (setPriority0)

```Java
private void init(ThreadGroup g, Runnable target, String name,
                  long stackSize, AccessControlContext acc,
                  boolean inheritThreadLocals) {
    // 线程名name默认为 "Thread-" + nextThreadNum()
    if (name == null) {
        throw new NullPointerException("name cannot be null");
    }

    this.name = name;
    // 依据当前线程的group、daemon、priority、contextClassLoader、inheritableThreadLocals参数设置当前新建线程的对应参数
    Thread parent = currentThread();
    SecurityManager security = System.getSecurityManager();
    if (g == null) {
        if (security != null) {
            g = security.getThreadGroup();
        }
        if (g == null) {
            g = parent.getThreadGroup();
        }
    }
    g.checkAccess();
    if (security != null) {
        if (isCCLOverridden(getClass())) {
            security.checkPermission(SUBCLASS_IMPLEMENTATION_PERMISSION);
        }
    }
    g.addUnstarted();

    this.group = g;
    this.daemon = parent.isDaemon();
    this.priority = parent.getPriority();
    if (security == null || isCCLOverridden(parent.getClass()))
        this.contextClassLoader = parent.getContextClassLoader();
    else
        this.contextClassLoader = parent.contextClassLoader;
    this.inheritedAccessControlContext =
            acc != null ? acc : AccessController.getContext();
    this.target = target;
    setPriority(priority);
    if (inheritThreadLocals && parent.inheritableThreadLocals != null)
        this.inheritableThreadLocals =
            ThreadLocal.createInheritedMap(parent.inheritableThreadLocals);
    // 线程栈大小
    this.stackSize = stackSize;

    // 线程ID
    tid = nextThreadID();
}
```

# start() 之后干了什么

1. 检查线程状态，如果线程状态不为 NEW，抛出异常
2. 将线程加入到线程组中
3. 调用 start0() 启动线程，此时会创建一个 OSThread 并与 Java Thread 建立映射关系，然后启动(start) OSThread，在这里才真正创建一个线程，在 new Thread() 时仅仅是创建了一个 Java Thread 对象
4. 如果线程启动失败，将当前线程从线程组中移除

```Java
public synchronized void start() {
    // 检查线程状态，如果线程状态不为NEW，抛出异常
    if (threadStatus != 0)
        throw new IllegalThreadStateException();
    // 将当前线程加入到线程组中，线程组 nUnstartedThreads --
    group.add(this);

    boolean started = false;
    try {
        start0();
        started = true;
    } finally {
        try {
            // 如果启动线程失败，将当前线程从线程组移除 nUnstartedThreads ++
            if (!started) {
                group.threadStartFailed(this);
            }
        } catch (Throwable ignore) {
            /* do nothing. If start0 threw a Throwable then
              it will be passed up the call stack */
        }
    }
}
```

# sleep()  的过程

1. 线程睡眠，在睡眠过程中如果当前线程被<a href="#interrupt">中断</a>，会抛出 InterruptedException 异常，并清除线程的中断状态
2. sleep 过程依赖于 pthread_cond_timedwait() 函数(Linux 平台)，该函数使得线程等待一定的时间，如果超时或有信号触发(pthread_cond_signal() )，线程唤醒。当线程被中断时，会调用 unpark() 函数，即 pthread_cond_signal() ，唤醒线程

```c++
//  hotspot/src/share/vm/prims/jvm.cpp:3155
JVM_ENTRY(void, JVM_Sleep(JNIEnv* env, jclass threadClass, jlong millis))
  JVMWrapper("JVM_Sleep");

  if (millis < 0) {
    THROW_MSG(vmSymbols::java_lang_IllegalArgumentException(), "timeout value is negative");
  }
  // 如果当前线程被中断，会抛出InterruptedException异常，并清除中断状态
  if (Thread::is_interrupted (THREAD, true) && !HAS_PENDING_EXCEPTION) {
    THROW_MSG(vmSymbols::java_lang_InterruptedException(), "sleep interrupted");
  }

  // Save current thread state and restore it at the end of this block.
  // And set new thread state to SLEEPING.
  JavaThreadSleepState jtss(thread);

#ifndef USDT2
  HS_DTRACE_PROBE1(hotspot, thread__sleep__begin, millis);
#else /* USDT2 */
  HOTSPOT_THREAD_SLEEP_BEGIN(
                             millis);
#endif /* USDT2 */

  EventThreadSleep event;
   // 如果设置了ConvertSleepToYield参数为true(默认为false)当 millis == 0 时，实际上等价于调用了 yield() 方法
  if (millis == 0) {
    // When ConvertSleepToYield is on, this matches the classic VM implementation of
    // JVM_Sleep. Critical for similar threading behaviour (Win32)
    // It appears that in certain GUI contexts, it may be beneficial to do a short sleep
    // for SOLARIS
    if (ConvertSleepToYield) {
      os::yield();
    } else {
      ThreadState old_state = thread->osthread()->get_state();
      thread->osthread()->set_state(SLEEPING);
      os::sleep(thread, MinSleepInterval, false);
      thread->osthread()->set_state(old_state);
    }
  } else {
     // 在sleep期间会将线程状态设置为SLEEPING，sleep完毕再设置回原来的状态
    ThreadState old_state = thread->osthread()->get_state();
    thread->osthread()->set_state(SLEEPING);
    if (os::sleep(thread, millis, true) == OS_INTRPT) {
      // An asynchronous exception (e.g., ThreadDeathException) could have been thrown on
      // us while we were sleeping. We do not overwrite those.
      if (!HAS_PENDING_EXCEPTION) {
        if (event.should_commit()) {
          event.set_time(millis);
          event.commit();
        }
#ifndef USDT2
        HS_DTRACE_PROBE1(hotspot, thread__sleep__end,1);
#else /* USDT2 */
        HOTSPOT_THREAD_SLEEP_END(
                                 1);
#endif /* USDT2 */
        // TODO-FIXME: THROW_MSG returns which means we will not call set_state()
        // to properly restore the thread state.  That's likely wrong.
        THROW_MSG(vmSymbols::java_lang_InterruptedException(), "sleep interrupted");
      }
    }
    thread->osthread()->set_state(old_state);
  }
  if (event.should_commit()) {
    event.set_time(millis);
    event.commit();
  }
#ifndef USDT2
  HS_DTRACE_PROBE1(hotspot, thread__sleep__end,0);
#else /* USDT2 */
  HOTSPOT_THREAD_SLEEP_END(
                           0);
#endif /* USDT2 */
JVM_END
```

```c++
//  hotspot/src/os/linux/vm/os_linux.cpp:3764
int os::sleep(Thread* thread, jlong millis, bool interruptible) {
  assert(thread == Thread::current(),  "thread consistency check");

  ParkEvent * const slp = thread->_SleepEvent ;
  slp->reset() ;
  OrderAccess::fence() ;
  // 是否响应中断信号
  if (interruptible) {
    jlong prevtime = javaTimeNanos();

    for (;;) {
      // 如果当前线程被中断，清除中断状态，并返回响应码OS_INTRPT
      if (os::is_interrupted(thread, true)) {
        return OS_INTRPT;
      }

      jlong newtime = javaTimeNanos();

      if (newtime - prevtime < 0) {
        // time moving backwards, should only happen if no monotonic clock
        // not a guarantee() because JVM should not abort on kernel/glibc bugs
        assert(!Linux::supports_monotonic_clock(), "time moving backwards");
      } else {
        millis -= (newtime - prevtime) / NANOSECS_PER_MILLISEC;
      }

      if(millis <= 0) {
        return OS_OK;
      }

      prevtime = newtime;

      {
        assert(thread->is_Java_thread(), "sanity check");
        JavaThread *jt = (JavaThread *) thread;
        ThreadBlockInVM tbivm(jt);
        OSThreadWaitState osts(jt->osthread(), false /* not Object.wait() */);

        jt->set_suspend_equivalent();
        // cleared by handle_special_suspend_equivalent_condition() or
        // java_suspend_self() via check_and_wait_while_suspended()
        // 阻塞 millis时间，单位:毫秒
        slp->park(millis);

        // were we externally suspended while we were waiting?
        jt->check_and_wait_while_suspended();
      }
    }
  } else {
    // 如果不响应中断信号，那么将忽略 os::is_interrupted(thread, true)
    OSThreadWaitState osts(thread->osthread(), false /* not Object.wait() */);
    jlong prevtime = javaTimeNanos();

    for (;;) {
      // It'd be nice to avoid the back-to-back javaTimeNanos() calls on
      // the 1st iteration ...
      jlong newtime = javaTimeNanos();

      if (newtime - prevtime < 0) {
        // time moving backwards, should only happen if no monotonic clock
        // not a guarantee() because JVM should not abort on kernel/glibc bugs
        assert(!Linux::supports_monotonic_clock(), "time moving backwards");
      } else {
        millis -= (newtime - prevtime) / NANOSECS_PER_MILLISEC;
      }

      if(millis <= 0) break ;

      prevtime = newtime;
      // 阻塞 millis 毫秒
      slp->park(millis);
    }
    return OS_OK ;
  }
}
```

```c++
//  hotspot/src/os/linux/vm/os_linux.cpp:5663
int os::PlatformEvent::park(jlong millis) {
  guarantee (_nParked == 0, "invariant") ;

  int v ;
  for (;;) {
      v = _Event ;
      if (Atomic::cmpxchg (v-1, &_Event, v) == v) break ;
  }
  guarantee (v >= 0, "invariant") ;
  if (v != 0) return OS_OK ;

  // We do this the hard way, by blocking the thread.
  // Consider enforcing a minimum timeout value.
  struct timespec abst;
  compute_abstime(&abst, millis);

  int ret = OS_TIMEOUT;
  int status = pthread_mutex_lock(_mutex);
  assert_status(status == 0, status, "mutex_lock");
  guarantee (_nParked == 0, "invariant") ;
  ++_nParked ;

  // Object.wait(timo) will return because of
  // (a) notification
  // (b) timeout
  // (c) thread.interrupt
  //
  // Thread.interrupt and object.notify{All} both call Event::set.
  // That is, we treat thread.interrupt as a special case of notification.
  // The underlying Solaris implementation, cond_timedwait, admits
  // spurious/premature wakeups, but the JLS/JVM spec prevents the
  // JVM from making those visible to Java code.  As such, we must
  // filter out spurious wakeups.  We assume all ETIME returns are valid.
  //
  // TODO: properly differentiate simultaneous notify+interrupt.
  // In that case, we should propagate the notify to another waiter.

  while (_Event < 0) {
    status = os::Linux::safe_cond_timedwait(_cond, _mutex, &abst);
    if (status != 0 && WorkAroundNPTLTimedWaitHang) {
      pthread_cond_destroy (_cond);
      pthread_cond_init (_cond, os::Linux::condAttr()) ;
    }
    assert_status(status == 0 || status == EINTR ||
                  status == ETIME || status == ETIMEDOUT,
                  status, "cond_timedwait");
    if (!FilterSpuriousWakeups) break ;                 // previous semantics
    if (status == ETIME || status == ETIMEDOUT) break ;
    // We consume and ignore EINTR and spurious wakeups.
  }
  --_nParked ;
  if (_Event >= 0) {
     ret = OS_OK;
  }
  _Event = 0 ;
  status = pthread_mutex_unlock(_mutex);
  assert_status(status == 0, status, "mutex_unlock");
  assert (_nParked == 0, "invariant") ;
  // Paranoia to ensure our locked and lock-free paths interact
  // correctly with each other.
  OrderAccess::fence();
  return ret;
}
```

```c++
// hotspot/src/os/linux/vm/os_linux.cpp:5034
int os::Linux::safe_cond_timedwait(pthread_cond_t *_cond, pthread_mutex_t *_mutex, const struct timespec *_abstime)
{
   if (is_NPTL()) {
      return pthread_cond_timedwait(_cond, _mutex, _abstime);
   } else {
      // 6292965: LinuxThreads pthread_cond_timedwait() resets FPU control
      // word back to default 64bit precision if condvar is signaled. Java
      // wants 53bit precision.  Save and restore current value.
      int fpu = get_fpu_control_word();
      int status = pthread_cond_timedwait(_cond, _mutex, _abstime);
      set_fpu_control_word(fpu);
      return status;
   }
}
```

# <a name="interrupt">几个 interrupt 方法</a>

### 1. public void interrupt()

非 static 方法，在一个线程中调用自己或另一个线程对象(objThread)的 interrupt()方法，会给线程 objThread 发送一个中断信号，将该线程的中断标志位(_interrupted)置为 1；同时，唤醒线程！

```Java
public void interrupt() {
    if (this != Thread.currentThread())
        checkAccess();

    synchronized (blockerLock) {
        Interruptible b = blocker;
        if (b != null) {
            interrupt0();           // Just to set the interrupt flag
            b.interrupt(this);
            return;
        }
    }
    interrupt0();
}
```

### 2. public static boolean interrupted()

static 方法，检查当前线程是否被中断，并清除中断状态(_interrupted 置为 0)

```Java
public static boolean interrupted() {
    return currentThread().isInterrupted(true);
}
```

### 3. public boolean isInterrupted()

非 static 方法，用于检查被调用线程是否被中断，不会清除中断状态

```Java
public boolean isInterrupted() {
    return isInterrupted(false);
}
```

---
### native 方法源码跟踪（详细代码可下载 [openjdk 源码](http://www.zousanchuan.com/articles/2019/09/17/1568715638871.html) 查看）：

#### 1. interrupt0 方法执行流程：

```java
private native void interrupt0();
```

```c++
//  jdk/src/share/native/java/lang/Thread.c:54
static JNINativeMethod methods[] = {
    ...................
    {"interrupt0",       "()V",        (void *)&JVM_Interrupt},
    ...................
};
```

```c++
//  hotspot/src/share/vm/prims/jvm.cpp:3289
JVM_ENTRY(void, JVM_Interrupt(JNIEnv* env, jobject jthread))
  JVMWrapper("JVM_Interrupt");

  // Ensure that the C++ Thread and OSThread structures aren't freed before we operate
  oop java_thread = JNIHandles::resolve_non_null(jthread);
  MutexLockerEx ml(thread->threadObj() == java_thread ? NULL : Threads_lock);
  // We need to re-resolve the java_thread, since a GC might have happened during the
  // acquire of the lock
  JavaThread* thr = java_lang_Thread::thread(JNIHandles::resolve_non_null(jthread));
  if (thr != NULL) {
    Thread::interrupt(thr);
  }
JVM_END
```

```c++
//  hotspot/src/share/vm/runtime/thread.cpp:804
void Thread::interrupt(Thread* thread) {
  trace("interrupt", thread);
  debug_only(check_for_dangling_thread_pointer(thread);)
  os::interrupt(thread);
}
```

```c++
//  hotspot/src/os/linux/vm/os_linux.cpp:4192
void os::interrupt(Thread* thread) {
  assert(Thread::current() == thread || Threads_lock->owned_by_self(),
    "possibility of dangling Thread pointer");

  OSThread* osthread = thread->osthread();

  if (!osthread->interrupted()) {
    osthread->set_interrupted(true);
    // More than one thread can get here with the same value of osthread,
    // resulting in multiple notifications.  We do, however, want the store
    // to interrupted() to be visible to other threads before we execute unpark().
    OrderAccess::fence();
    ParkEvent * const slp = thread->_SleepEvent ;
    if (slp != NULL) slp->unpark() ;
  }

  // For JSR166. Unpark even if interrupt status already was set
  if (thread->is_Java_thread())
    ((JavaThread*)thread)->parker()->unpark();

  ParkEvent * ev = thread->_ParkEvent ;
  if (ev != NULL) ev->unpark() ;
}
```

```c++
//  hotspot/src/share/vm/runtime/osThread.hpp:89
void set_interrupted(bool z) { _interrupted = z ? 1 : 0; }
```

```c++
//  hotspot/src/os/linux/vm/os_linux.cpp:5727
void os::PlatformEvent::unpark() {
  // Transitions for _Event:
  //    0 :=> 1
  //    1 :=> 1
  //   -1 :=> either 0 or 1; must signal target thread
  //          That is, we can safely transition _Event from -1 to either
  //          0 or 1. Forcing 1 is slightly more efficient for back-to-back
  //          unpark() calls.
  // See also: "Semaphores in Plan 9" by Mullender & Cox
  //
  // Note: Forcing a transition from "-1" to "1" on an unpark() means
  // that it will take two back-to-back park() calls for the owning
  // thread to block. This has the benefit of forcing a spurious return
  // from the first park() call after an unpark() call which will help
  // shake out uses of park() and unpark() without condition variables.

  if (Atomic::xchg(1, &_Event) >= 0) return;

  // Wait for the thread associated with the event to vacate
  int status = pthread_mutex_lock(_mutex);
  assert_status(status == 0, status, "mutex_lock");
  int AnyWaiters = _nParked;
  assert(AnyWaiters == 0 || AnyWaiters == 1, "invariant");
  if (AnyWaiters != 0 && WorkAroundNPTLTimedWaitHang) {
    AnyWaiters = 0;
    pthread_cond_signal(_cond);
  }
  status = pthread_mutex_unlock(_mutex);
  assert_status(status == 0, status, "mutex_unlock");
  if (AnyWaiters != 0) {
    status = pthread_cond_signal(_cond);
    assert_status(status == 0, status, "cond_signal");
  }

  // Note that we signal() _after dropping the lock for "immortal" Events.
  // This is safe and avoids a common class of  futile wakeups.  In rare
  // circumstances this can cause a thread to return prematurely from
  // cond_{timed}wait() but the spurious wakeup is benign and the victim will
  // simply re-test the condition and re-park itself.
}
```

---
#### 2. isInterrupted 方法执行流程

```Java
private native boolean isInterrupted(boolean ClearInterrupted);
```

```c++
//  jdk/src/share/native/java/lang/Thread.c:55  
static JNINativeMethod methods[] = {  
 ...................  
 {"isInterrupted",    "(Z)Z",       (void *)&JVM_IsInterrupted},  
 ...................  
};  
```

```c++
//  hotspot/src/share/vm/prims/jvm.cpp:3304  
JVM_QUICK_ENTRY(jboolean, JVM_IsInterrupted(JNIEnv* env, jobject jthread, jboolean clear_interrupted))
  JVMWrapper("JVM_IsInterrupted");

  // Ensure that the C++ Thread and OSThread structures aren't freed before we operate
  oop java_thread = JNIHandles::resolve_non_null(jthread);
  MutexLockerEx ml(thread->threadObj() == java_thread ? NULL : Threads_lock);
  // We need to re-resolve the java_thread, since a GC might have happened during the
  // acquire of the lock
  JavaThread* thr = java_lang_Thread::thread(JNIHandles::resolve_non_null(jthread));
  if (thr == NULL) {
    return JNI_FALSE;
  } else {
    return (jboolean) Thread::is_interrupted(thr, clear_interrupted != 0);
  }
JVM_END
  
```

```c++
//  hotspot/src/share/vm/runtime/thread.cpp:810  
bool Thread::is_interrupted(Thread* thread, bool clear_interrupted) {  
 trace("is_interrupted", thread);  
 debug_only(check_for_dangling_thread_pointer(thread);)  
 // Note:  If clear_interrupted==false, this simply fetches and  
 // returns the value of the field osthread()->interrupted().  
 return os::is_interrupted(thread, clear_interrupted);  
}  
  
```

```c++
//  hotspot/src/os/linux/vm/os_linux.cpp:4217  
bool os::is_interrupted(Thread* thread, bool clear_interrupted) {  
 assert(Thread::current() == thread || Threads_lock->owned_by_self(),  
 "possibility of dangling Thread pointer");  
  
 OSThread* osthread = thread->osthread();  
  
 bool interrupted = osthread->interrupted();  
  
 if (interrupted && clear_interrupted) {  
 osthread->set_interrupted(false);  
 // consider thread->_SleepEvent->reset() ... optional optimization  
 }  
  
 return interrupted;  
}  
  
```

```c++
//  hotspot/src/share/vm/runtime/osThread.hpp:88  
volatile bool interrupted() const    { return _interrupted != 0; }  
```
# join() 方法
1. 在当前线程中，如果调用另一个线程的join方法时，当前线程会阻塞直到被调用的线程执行完成 或者 超出超时时间 后才可以继续执行
2. join() 方法依赖于 Object 的 wait() 方法实现，如果不指定超时时间或者超时时间为0，那么当前线程将一直等待直至被调用 join() 方法的线程死亡
```Java
public final void join() throws InterruptedException { join(0); }

public final synchronized void join(long millis)
throws InterruptedException {
    long base = System.currentTimeMillis();
    long now = 0;

    if (millis < 0) {
        throw new IllegalArgumentException("timeout value is negative");
    }

    if (millis == 0) {
        while (isAlive()) {
            wait(0);
        }
    } else {
        while (isAlive()) {
            long delay = millis - now;
            if (delay <= 0) {
                break;
            }
            wait(delay);
            now = System.currentTimeMillis() - base;
        }
    }
}
```
