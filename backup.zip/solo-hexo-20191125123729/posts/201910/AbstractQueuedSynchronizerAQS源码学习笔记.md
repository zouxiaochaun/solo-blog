title: AbstractQueuedSynchronizer(AQS) 源码学习笔记
date: '2019-10-29 15:01:59'
updated: '2019-10-29 15:20:56'
tags: [AQS, JUC]
permalink: /articles/2019/10/29/1572332519063.html
---
# 简介

`AbstractQueuedSynchronizer`(`AQS`) 是一个依赖于先入先出队列的同步器框架，通过一个`violate int`值`state`来控制同步器状态，`violate`保证了`state`的多线程可见性，由`CAS` 和 `自旋操作` 确保正确更新`state`值。

`AQS`提供了两种同步器模式，独占模式和共享模式。

在独占模式下同时只能有一个线程持有锁资源，下一个线程必须在同步队列中等待已持有锁资源的线程释放锁并将等待的线程唤醒，然后被唤醒的线程再竞争独占锁。

而在共享模式下同时可以存在多个线程获取到锁资源，下一个线程是否可以获取到锁取决于上一个线程获取锁之后是否还有资源余量可供下一个线程获取，如果没有资源余量那么后续竞争共享锁资源的线程也将被放入同步队列中排队等待，这个资源余量由`tryAcquireShared`方法的返回值体现

子类通过重写`AQS`提供的几个`protected`方法实现不同的同步器功能，这几个方法决定了独占模式锁和共享模式锁的行为，子类也可以不实现对应方法，`AQS`默认抛出`UnsupportedOperationException`异常，即子类不支持这样的操作。

`JUC`预置了几个`AQS`的子类实例，如`ReentrantLock`和`ReentrantReadWriteLock`，需要注意的是`ReentrantLock`和`ReentrantReadWriteLock`并不直接继承`AQS`，而是由其内部类`Sync`来继承`AQS`的功能，`XxxxLock`类实现`Lock`接口，提供`lock`和`unlock`等功能

同时，`AQS`还提供 `等待(await)` / `通知(signal)` 机制，类似`Object`的`wait`和`notify`

# 由子类负责实现的方法

```java
// 尝试以独占模式获取锁资源，获取成功返回true，获取失败返回false
// 如果失败，acquire方法将会把当前线程加入到队列中    
protected boolean tryAcquire(int arg) {
    throw new UnsupportedOperationException();
}

// 独占模式释放锁资源
// 如果锁资源已被完全释放，其他等待线程可以尝试获取，返回true，否则返回false
protected boolean tryRelease(int arg) {
    throw new UnsupportedOperationException();
}

// 尝试以共享模式获取锁资源
// 返回负数表示获取失败；0表示成功，但没有剩余可用资源；正数表示获取成功并且有剩余资源
// 如果失败，acquireShared方法将会把当前线程加入到队列中
protected int tryAcquireShared(int arg) {
    throw new UnsupportedOperationException();
}

// 共享模式释放锁资源
// 释放后如果允许唤醒后续等待结点，返回true，否则返回false。
protected boolean tryReleaseShared(int arg) {
    throw new UnsupportedOperationException();
}

// 该线程是否正在独占资源。只有用到condition才需要去实现它
protected boolean isHeldExclusively() {
    throw new UnsupportedOperationException();
}
```

# 实现分析

## 独占模式

### acquire(int)

以独占模式获取锁资源，获取成功直接返回，否则当前线程将被加入到同步队列中阻塞等待锁资源。阻塞过程中不响应线程中断信号

1. 首先会调用 `tryAcquire(arg)` 方法尝试以独占模式获取锁资源，如果获取成功则直接返回，获取失败则通过`acquireQueued`将当前线程加入到同步队列阻塞等待获取锁
2. 如果阻塞过程线程被中断过，则需要产生一个中断。作用是为了还原线程状态，因为在`acquireQueued`中如果检测到线程有过中断的话会重置线程的中断状态。

```java
public final void acquire(int arg) {
    if (!tryAcquire(arg) &&
        acquireQueued(addWaiter(Node.EXCLUSIVE), arg))
        selfInterrupt();
}
```

`acquireQueued`方法参数`node`中封装的是当前线程，该方法会一直自旋检查`node`的状态是否可以获取到锁。如果获取锁失败，线程会进入阻塞状态等待被唤醒。
唤醒方式有`unpark`的方式和中断方式，如果在阻塞过程中发生过线程中断，获取锁成功后将返回`true`，没有线程中断则返回`false`，返回之前会将`node`中的线程删除，并更新队列头结点`head`指针到`node`

```java
final boolean acquireQueued(final Node node, int arg) {
    // 节点入队失败  
    boolean failed = true;
    try {
        // 线程是否被中断  
        boolean interrupted = false;
        // 自旋  
        for (;;) {
            // node节点的前置节点  
            final Node p = node.predecessor();
            // 如果前置节点是头结点，直接尝试获取锁  
            if (p == head && tryAcquire(arg)) {
                // 获取锁资源成功，头结点指针后移  
                setHead(node);
                p.next = null; // help GC  
                failed = false;
                return interrupted;
            }
            // 前置节点不是头结点，或者获取锁失败  
            // 如果node节点具备park条件则调用进入park状态  
            // 如果阻塞过程中发生了线程中断导致线程被唤醒，那么将interrupted置为true，当线程成功获取到锁之后会返回interrupted状态  
            if (shouldParkAfterFailedAcquire(p, node) &&
                    parkAndCheckInterrupt())
                interrupted = true;
        }
    } finally {
        if (failed)
            cancelAcquire(node);
    }
}
```

`addWaiter` 的作用是将当前线程封装成一个`Node`对象挂在同步队列尾部，并返回封装的`Node`对象，主要逻辑包括：

1. 将当前线程封装以指定模式封装到 Node 对象中，`mode` 枚举值有`Node.EXCLUSIVE`(独占模式)和 `Node.SHARED`(共享模式)
2. 检查同步队列尾节点是否为`null`，尾节点为`null`说明队列还未初始化，直接调用`enq`方法初始化同步队列，同时将节点`node`插入队列尾部
3. 如果尾节点不为`null`，将`node`更新为尾节点，更新成功直接返回，更新失败则调用`enq`方法自旋更新尾节点
4. 返回封装了当前线程的`Node`对象

```java
private Node addWaiter(Node mode) {
    // 将当前线程封装为Node节点
    Node node = new Node(Thread.currentThread(), mode);
    // Try the fast path of enq; backup to full enq on failure
    Node pred = tail;
    // 尝试在尾部快速添加
    if (pred != null) {
        node.prev = pred;
        // cas操作保证tail指针安全更新
        if (compareAndSetTail(pred, node)) {
            pred.next = node;
            return node;
        }
    }
    // 同步队列为初始化 或者 快速插入尾部失败，自旋插入
    enq(node);
    return node;
}
```

`enq` 的逻辑主要包括：

1. 检查并初始化同步队列，同步队列中头结点`thread`属性值始终为`null`
2. 自旋，直到节点插入队列尾部成功

```java
private Node enq(final Node node) {
    for (;;) {
        Node t = tail;
        if (t == null) { // Must initialize
            if (compareAndSetHead(new Node()))
                tail = head;
        } else {
            node.prev = t;
            if (compareAndSetTail(t, node)) {
                t.next = node;
                return t;
            }
        }
    }
}
```

`shouldParkAfterFailedAcquire` ，判断当前线程获取锁失败后是否可以`park`，即是否具备`park`条件，，返回`true`表示线程需要`park`，`false`则不需要

```java
private static boolean shouldParkAfterFailedAcquire(Node pred, Node node) {
    int ws = pred.waitStatus;
    if (ws == Node.SIGNAL)
        /*
         * This node has already set status asking a release
         * to signal it, so it can safely park.
         */
    	// 如果前置节点的waitStatus是Node.SIGNAL，则返回true
        return true;
    if (ws > 0) {
        /*
         * Predecessor was cancelled. Skip over predecessors and
         * indicate retry.
         */
        // 去除队列中所有已取消的节点 (Node.CANCELLED)
        do {
            node.prev = pred = pred.prev;
        } while (pred.waitStatus > 0);
        pred.next = node;
    } else {
        /*
         * waitStatus must be 0 or PROPAGATE.  Indicate that we
         * need a signal, but don't park yet.  Caller will need to
         * retry to make sure it cannot acquire before parking.
         */
        // 此时ws的值只能是 0 或 Node.PROPAGATE
        compareAndSetWaitStatus(pred, ws, Node.SIGNAL);
    }
    return false;
}
```

`parkAndCheckInterrupt`方法的作用是让当前线程进入阻塞状态，如果线程是正常被唤醒（`unpark`）则返回`false`，如果线程是被中断唤醒，则返回`true`，同时会清除线程中断状态

```java
private final boolean parkAndCheckInterrupt() {
    LockSupport.park(this);
    return Thread.interrupted();
}
```

线程获取锁失败后调用`cancelAcquire`方法删除队列中对应`node`，传入的参数是当前获取锁资源失败的节点

```java
private void cancelAcquire(Node node) {
    // node为获取锁失败的节点
    // 如果node不存在直接退出
    if (node == null)
        return;

    node.thread = null;

    // 清除前置节点中已被取消的节点
    Node pred = node.prev;
    while (pred.waitStatus > 0)
        node.prev = pred = pred.prev;

    // 经过上面的while清除被取消的节点后，predNext 有可能已经不是 node
    Node predNext = pred.next;

    // 设置node状态为Node.CANCELLED
    node.waitStatus = Node.CANCELLED;

    // 如果node是尾节点，直接通过cas设置尾节点指针为node的前置节点，逻辑删除node节点
    if (node == tail && compareAndSetTail(node, pred)) {
        // 取消前置节点的next指针指向
        // 这里不用关注CASNext的结果，即使CASNext失败，下一个节点插入队列时也会更新next指针
        compareAndSetNext(pred, predNext, null);
    } else {
        // 走到这里说明node已不是尾节点
        int ws;
        if (
            // node的前置节点不是头结点
            pred != head &&
            // node的前置节点waitStatus是Node.SIGNAL
            ((ws = pred.waitStatus) == Node.SIGNAL ||
             // node的前置节点waitStatus是Node.PROPAGATE，并且更新前置节点waitStatus成功
             (ws <= 0 && compareAndSetWaitStatus(pred, ws, Node.SIGNAL))) &&
            pred.thread != null) {
            // 总结以上条件为 node的前置节点不是头结点 并且 node之后的节点等待被唤醒
            Node next = node.next;
            // node的后继节点没有被取消
            if (next != null && next.waitStatus <= 0)
            	// 前置节点的next指针指向next，将node从next指针链中删除
            	// pred指针链并没有删除node节点
                compareAndSetNext(pred, predNext, next);
        } else {
            // node的前置节点是头结点
            // node的前置节点的waitStatus是Node.PROPAGATE
            // 满足以上任意条件，在node获取锁失败的情况下，会唤醒node的后继节点获取锁
            unparkSuccessor(node);
        }

        node.next = node; // help GC
    }
}
```

唤醒`node`节点后继节点的方法，

```java
private void unparkSuccessor(Node node) {
    // 置零当前线程所在的结点状态，允许失败。
    int ws = node.waitStatus;
    if (ws < 0)
        compareAndSetWaitStatus(node, ws, 0);

    /*
     * Thread to unpark is held in successor, which is normally
     * just the next node.  But if cancelled or apparently null,
     * traverse backwards from tail to find the actual
     * non-cancelled successor.
     */
    // 拿到下一个节点
    Node s = node.next;
    // 如果下一个节点是空或者已取消
    if (s == null || s.waitStatus > 0) {
        s = null;
        // 从后往前遍历队列找到最靠前的有效的(waitStatus <= 0)节点
        for (Node t = tail; t != null && t != node; t = t.prev)
            if (t.waitStatus <= 0)
                s = t;
    }
    if (s != null)
        // 唤醒节点
        LockSupport.unpark(s.thread);
}
```

### acquireInterruptibly(int)

响应中断信号的获取独占锁方法。相比于`acquire`，方法`acquireInterruptibly`方法会响应线程中断信号，在阻塞等待获取锁过程中如果线程被中断，`acquireInterruptibly`方法会抛出`InterruptedException`异常

```java
public final void acquireInterruptibly(int arg)
        throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    if (!tryAcquire(arg))
        doAcquireInterruptibly(arg);
}
```

`doAcquireInterruptibly`首先以独占模式封装当前线程插入同步队列，在等待锁的过程中如果发生线程中断会直接抛出`InterruptedException`异常

```java
private void doAcquireInterruptibly(int arg)
    throws InterruptedException {
    // 以独占模式封装当前线程插入同步队列
    final Node node = addWaiter(Node.EXCLUSIVE);
    boolean failed = true;
    try {
        for (;;) {
            // 如果当前节点的前置节点是头结点，并且成功获取到锁，则将当前线程从队列中删除，并更新头结点指针(head)指向node，无返回值
            final Node p = node.predecessor();
            if (p == head && tryAcquire(arg)) {
                setHead(node);
                p.next = null; // help GC
                failed = false;
                return;
            }
            // 类似acquireQueued方法中的逻辑，区别在于在acquireQueued中如果线程被中断会更新一个终点标记(interrupted = true)，获取锁成功后将这个标记作为返回值返回，而在这个方法中如果线程被中断的话直接抛出InterruptedException异常，因此中断信号无法中断acquire方法获取锁，却可以中断acquireInterruptibly获取锁直接返回
            if (shouldParkAfterFailedAcquire(p, node) &&
                parkAndCheckInterrupt())
                throw new InterruptedException();
        }
    } finally {
        if (failed)
            // 获取锁失败删除对应的node
            cancelAcquire(node);
    }
}
```

### tryAcquireNanos(int,long)

计时获取独占锁的方法，在给定时间内获取锁成功返回`true`，超时返回`false`，在等待锁的过程中如果线程被中断，会抛出`InterruptedException`异常

```java
public final boolean tryAcquireNanos(int arg, long nanosTimeout)
        throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    return tryAcquire(arg) ||
        doAcquireNanos(arg, nanosTimeout);
}
```

```java
private boolean doAcquireNanos(int arg, long nanosTimeout)
        throws InterruptedException {
    if (nanosTimeout <= 0L)
        return false;
    final long deadline = System.nanoTime() + nanosTimeout;
    // 以独占模式封装当前线程插入同步队列
    final Node node = addWaiter(Node.EXCLUSIVE);
    boolean failed = true;
    try {
        for (;;) {
            // 获取锁成功返回true
            final Node p = node.predecessor();
            if (p == head && tryAcquire(arg)) {
                setHead(node);
                p.next = null; // help GC
                failed = false;
                return true;
            }
            // 超时返回false
            nanosTimeout = deadline - System.nanoTime();
            if (nanosTimeout <= 0L)
                return false;
            // 阻塞等待锁，如果最后的1000纳秒线程被唤醒但是获取锁失败，线程不再以阻塞的方式等待，而是直接不断轮询node状态，直到超时或者获取锁成功
            if (shouldParkAfterFailedAcquire(p, node) &&
                nanosTimeout > spinForTimeoutThreshold)
                LockSupport.parkNanos(this, nanosTimeout);
            // 如果线程被中断抛出InterruptedException异常，清除线程中断状态
            if (Thread.interrupted())
                throw new InterruptedException();
        }
    } finally {
        if (failed)
            cancelAcquire(node);
    }
}
```

### release(int)

释放独占锁的方法。释放成功则唤醒头结点的后继节点，并返回`true`

```java
public final boolean release(int arg) {
    if (tryRelease(arg)) {
        Node h = head;
        if (h != null && h.waitStatus != 0)
            unparkSuccessor(h);
        return true;
    }
    return false;
}
```

## 共享模式

### acquireShared(int)

以独占模式获取锁资源，`tryAcquireShared`方法返回负数表示获取共享锁失败，需要将当前线程放入队列中等待锁资源

```java
public final void acquireShared(int arg) {
    if (tryAcquireShared(arg) < 0)
        doAcquireShared(arg);
}
```

```java
private void doAcquireShared(int arg) {
    // 将当前线程插入队列
    final Node node = addWaiter(Node.SHARED);
    boolean failed = true;
    try {
        boolean interrupted = false;
        for (;;) {
            // 如果node的前置节点是头结点，即已轮到node获取锁
            final Node p = node.predecessor();
            if (p == head) {
                // 尝试获取锁
                int r = tryAcquireShared(arg);
                // r>=0 获取锁成功
                if (r >= 0) {
                    setHeadAndPropagate(node, r);
                    p.next = null; // help GC
                    // 
                    if (interrupted)
                        selfInterrupt();
                    failed = false;
                    return;
                }
            }
            if (shouldParkAfterFailedAcquire(p, node) &&
                parkAndCheckInterrupt())
                interrupted = true;
        }
    } finally {
        if (failed)
            cancelAcquire(node);
    }
}
```

`setHeadAndPropagate ` : 替换头结点为`node`，如果`node`的后继节点是共享模式节点，那么还会唤醒`node`的后继节点来获取锁

```java
private void setHeadAndPropagate(Node node, int propagate) {
    Node h = head; // Record old head for check below
    // 替换头结点
    setHead(node);
    // 如果共享锁还有剩余可用资源
    if (propagate > 0 || h == null || h.waitStatus < 0 ||
        (h = head) == null || h.waitStatus < 0) {
        Node s = node.next;
        // 如果node的后继节点是共享模式节点，同时唤醒node的后继节点
        if (s == null || s.isShared())
            doReleaseShared();
    }
}
```

`doReleaseShared` : 唤醒头结点的后继节点

```java
private void doReleaseShared() {
    for (;;) {
        Node h = head;
        if (h != null && h != tail) {
            int ws = h.waitStatus;
            // 如果头结点的waitStatus是Node.SIGNAL，那么需要唤醒头结点的后继节点
            if (ws == Node.SIGNAL) {
                if (!compareAndSetWaitStatus(h, Node.SIGNAL, 0))
                    continue;            // loop to recheck cases
                unparkSuccessor(h);
            }
            else if (ws == 0 &&
                     !compareAndSetWaitStatus(h, 0, Node.PROPAGATE))
                continue;                // loop on failed CAS
        }
        if (h == head)                   // loop if head changed
            break;
    }
}
```

### acquireSharedInterruptibly(int)

响应中断信号的获取共享锁方法。在获取共享锁的阻塞过程中，如果线程被中断，`acquireSharedInterruptibly`方法会直接抛出`InterruptedException`异常

```java
public final void acquireSharedInterruptibly(int arg)
        throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    if (tryAcquireShared(arg) < 0)
        doAcquireSharedInterruptibly(arg);
}
```

```java
private void doAcquireSharedInterruptibly(int arg)
    throws InterruptedException {
    final Node node = addWaiter(Node.SHARED);
    boolean failed = true;
    try {
        for (;;) {
            final Node p = node.predecessor();
            if (p == head) {
                int r = tryAcquireShared(arg);
                if (r >= 0) {
                    setHeadAndPropagate(node, r);
                    p.next = null; // help GC
                    failed = false;
                    return;
                }
            }
            // 如果线程被中断，直接抛出InterruptedException异常
            if (shouldParkAfterFailedAcquire(p, node) &&
                parkAndCheckInterrupt())
                throw new InterruptedException();
        }
    } finally {
        if (failed)
            cancelAcquire(node);
    }
}
```

### tryAcquireSharedNanos(int,long)

计时获取共享锁的方法，在给定时间内获取锁成功返回`true`，超时返回`false`，在等待锁的过程中如果线程被中断，会抛出`InterruptedException`异常

```java
public final boolean tryAcquireSharedNanos(int arg, long nanosTimeout)
        throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    return tryAcquireShared(arg) >= 0 ||
        doAcquireSharedNanos(arg, nanosTimeout);
}
```

```java
private boolean doAcquireSharedNanos(int arg, long nanosTimeout)
        throws InterruptedException {
    if (nanosTimeout <= 0L)
        return false;
    final long deadline = System.nanoTime() + nanosTimeout;
    final Node node = addWaiter(Node.SHARED);
    boolean failed = true;
    try {
        for (;;) {
            final Node p = node.predecessor();
            if (p == head) {
                int r = tryAcquireShared(arg);
                if (r >= 0) {
                    setHeadAndPropagate(node, r);
                    p.next = null; // help GC
                    failed = false;
                    return true;
                }
            }
            nanosTimeout = deadline - System.nanoTime();
            if (nanosTimeout <= 0L)
                return false;
            if (shouldParkAfterFailedAcquire(p, node) &&
                nanosTimeout > spinForTimeoutThreshold)
                LockSupport.parkNanos(this, nanosTimeout);
            //在等待锁的过程中如果线程被中断，会抛出InterruptedException异常
            if (Thread.interrupted())
                throw new InterruptedException();
        }
    } finally {
        if (failed)
            cancelAcquire(node);
    }
}
```

### releaseShared(int)

释放共享锁资源，释放成功则调用`doReleaseShared`唤醒后继节点

```java
public final boolean releaseShared(int arg) {
    if (tryReleaseShared(arg)) {
        doReleaseShared();
        return true;
    }
    return false;
}
```

## 等待

### await()

持续阻塞等待，直到其他线程调用`signal`或者`signalAll`方法通知该线程。等待过程响应中断，抛出`InterruptedException`。进入等待状态之前会释放锁，被通知唤醒之后再次获取锁。

```java
public final void await() throws InterruptedException {
    // 响应中断信号，抛出InterruptedException异常
    if (Thread.interrupted())
        throw new InterruptedException();
    Node node = addConditionWaiter();
    // 完全释放锁资源
    int savedState = fullyRelease(node);
    int interruptMode = 0;
    while (!isOnSyncQueue(node)) {
        // 只要node没有被转移到同步队列中，线程持续阻塞
        LockSupport.park(this);
        // 当线程被唤醒，检查唤醒原因，如果因为中断被唤醒，则需要响应线程中断，否则继续阻塞
        if ((interruptMode = checkInterruptWhileWaiting(node)) != 0)
            break;
    }
    // 重新上锁
    if (acquireQueued(node, savedState) && interruptMode != THROW_IE)
        interruptMode = REINTERRUPT;
    if (node.nextWaiter != null) // clean up if cancelled
        unlinkCancelledWaiters();
    // 响应中断
    if (interruptMode != 0)
        reportInterruptAfterWait(interruptMode);
}
```

将当前线程加入到等待队列中

```java
private Node addConditionWaiter() {
    Node t = lastWaiter;
    // If lastWaiter is cancelled, clean out.
    if (t != null && t.waitStatus != Node.CONDITION) {
        unlinkCancelledWaiters();
        t = lastWaiter;
    }
    Node node = new Node(Thread.currentThread(), Node.CONDITION);
    if (t == null)
        firstWaiter = node;
    else
        t.nextWaiter = node;
    lastWaiter = node;
    return node;
}
```

清除等待队列中所有`waitStatus`非`Node.CONDITION`状态的节点

```java
private void unlinkCancelledWaiters() {
    Node t = firstWaiter;
    Node trail = null;
    while (t != null) {
        Node next = t.nextWaiter;
        if (t.waitStatus != Node.CONDITION) {
            t.nextWaiter = null;
            if (trail == null)
                firstWaiter = next;
            else
                trail.nextWaiter = next;
            if (next == null)
                lastWaiter = trail;
        }
        else
            trail = t;
        t = next;
    }
}
```

### await(long, TimeUnit)

此方法跟`await()`方法的区别在于此方法设置了预期时间，在预设时间之内的逻辑与`await()`方法一致，如果超出预期时间还没有收到通知，那么会返回`false`，成功收到通知则返回`true`

```java
public final boolean await(long time, TimeUnit unit)
        throws InterruptedException {
    long nanosTimeout = unit.toNanos(time);
    if (Thread.interrupted())
        throw new InterruptedException();
    Node node = addConditionWaiter();
    int savedState = fullyRelease(node);
    final long deadline = System.nanoTime() + nanosTimeout;
    boolean timedout = false;
    int interruptMode = 0;
    while (!isOnSyncQueue(node)) {
        if (nanosTimeout <= 0L) {
            // 超时退出等待
            timedout = transferAfterCancelledWait(node);
            break;
        }
        if (nanosTimeout >= spinForTimeoutThreshold)
            // 阻塞给定的时间
            LockSupport.parkNanos(this, nanosTimeout);
        // 响应中断
        if ((interruptMode = checkInterruptWhileWaiting(node)) != 0)
            break;
        nanosTimeout = deadline - System.nanoTime();
    }
    if (acquireQueued(node, savedState) && interruptMode != THROW_IE)
        interruptMode = REINTERRUPT;
    if (node.nextWaiter != null)
        unlinkCancelledWaiters();
    if (interruptMode != 0)
        reportInterruptAfterWait(interruptMode);
    return !timedout;
}
```

### awaitNanos(long)

与`await(long, TimeUnit)`方法的逻辑一致。区别在于`await(long, TimeUnit)`方法可设定时间单位`TimeUnit`，而此方法时间单位固定为`纳秒`。并且此方法的`long`型返回值大于`0`代表等待剩余时间，等于或小于`0`代表等待超时

```java
public final long awaitNanos(long nanosTimeout)
        throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    Node node = addConditionWaiter();
    int savedState = fullyRelease(node);
    final long deadline = System.nanoTime() + nanosTimeout;
    int interruptMode = 0;
    while (!isOnSyncQueue(node)) {
        if (nanosTimeout <= 0L) {
            transferAfterCancelledWait(node);
            break;
        }
        if (nanosTimeout >= spinForTimeoutThreshold)
            LockSupport.parkNanos(this, nanosTimeout);
        if ((interruptMode = checkInterruptWhileWaiting(node)) != 0)
            break;
        nanosTimeout = deadline - System.nanoTime();
    }
    if (acquireQueued(node, savedState) && interruptMode != THROW_IE)
        interruptMode = REINTERRUPT;
    if (node.nextWaiter != null)
        unlinkCancelledWaiters();
    if (interruptMode != 0)
        reportInterruptAfterWait(interruptMode);
    return deadline - System.nanoTime();
}
```

### awaitUninterruptibly()

逻辑与`await()`方法一致，都是持续等待直到被其他线程通知唤醒。区别在于此方法不响应线程中断。

```java
public final void awaitUninterruptibly() {
    Node node = addConditionWaiter();
    int savedState = fullyRelease(node);
    boolean interrupted = false;
    while (!isOnSyncQueue(node)) {
        LockSupport.park(this);
        if (Thread.interrupted())
            interrupted = true;
    }
    if (acquireQueued(node, savedState) || interrupted)
        selfInterrupt();
}
```

### awaitUntil(Date)

逻辑与`await(long, TimeUnit)`方法一致，在`await(long, TimeUnit)`方法中设置的是从当前时间预期多长的时间段内收到通知，而在此方法中设置的是预期在哪个时间点之前收到通知，此方法返回值代表等待是否超时

```java
public final boolean awaitUntil(Date deadline)
        throws InterruptedException {
    long abstime = deadline.getTime();
    if (Thread.interrupted())
        throw new InterruptedException();
    Node node = addConditionWaiter();
    int savedState = fullyRelease(node);
    boolean timedout = false;
    int interruptMode = 0;
    while (!isOnSyncQueue(node)) {
        if (System.currentTimeMillis() > abstime) {
            timedout = transferAfterCancelledWait(node);
            break;
        }
        LockSupport.parkUntil(this, abstime);
        if ((interruptMode = checkInterruptWhileWaiting(node)) != 0)
            break;
    }
    if (acquireQueued(node, savedState) && interruptMode != THROW_IE)
        interruptMode = REINTERRUPT;
    if (node.nextWaiter != null)
        unlinkCancelledWaiters();
    if (interruptMode != 0)
        reportInterruptAfterWait(interruptMode);
    return !timedout;
}
```

## 通知

### signal()

将等待队列头部节点转移至同步队列中，等待同步队列中的前置节点将其唤醒，唤醒后继续执行 await 方法的后续流程

```java
public final void signal() {
    // 必须持有独占锁
    if (!isHeldExclusively())
        throw new IllegalMonitorStateException();
    Node first = firstWaiter;
    if (first != null)
        // 通知并转移等待队列头结点
        doSignal(first);
}
```

```java
private void doSignal(Node first) {
    do {
        // 替换firstWaiter指向的对象
        if ( (firstWaiter = first.nextWaiter) == null)
            lastWaiter = null;
        first.nextWaiter = null;
        // 转移节点first
    } while (!transferForSignal(first) &&
             (first = firstWaiter) != null);
}
```

```java
final boolean transferForSignal(Node node) {
    /*
     * If cannot change waitStatus, the node has been cancelled.
     */
    if (!compareAndSetWaitStatus(node, Node.CONDITION, 0))
        return false;
    /*
     * Splice onto queue and try to set waitStatus of predecessor to
     * indicate that thread is (probably) waiting. If cancelled or
     * attempt to set waitStatus fails, wake up to resync (in which
     * case the waitStatus can be transiently and harmlessly wrong).
     */
    // 将node转移到同步队列中
    Node p = enq(node);
    int ws = p.waitStatus;
    // 如果是已取消的节点或者cas操作失败，唤醒node中的线程
    // 唤醒node线程后，该线程将在await方法中退出阻塞，之后会在acquireQueued->shouldParkAfterFailedAcquire方法中修正前置节点p的waitStatus值，或者将已取消的node清除
    if (ws > 0 || !compareAndSetWaitStatus(p, ws, Node.SIGNAL))
        LockSupport.unpark(node.thread);
    return true;
}
```

### signalAll()

将等待队列中全部节点转移至同步队列中

```java
public final void signalAll() {
    // 通知的线程必须持有独占锁
    if (!isHeldExclusively())
        throw new IllegalMonitorStateException();
    Node first = firstWaiter;
    if (first != null)
        // 转移全部节点
        doSignalAll(first);
}
```

```java
private void doSignalAll(Node first) {
    lastWaiter = firstWaiter = null;
    // 通知并转移等待队列中所有节点
    do {
        Node next = first.nextWaiter;
        first.nextWaiter = null;
        transferForSignal(first);
        first = next;
    } while (first != null);
}
```

